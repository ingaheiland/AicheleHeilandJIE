% this file decomposes a country's total exports and bilateral exports into
% domestic, foreign, and double-counted value added, based on the decomposition method developed by Wang, Wei, and Zhu 2013 (NBER WP).
% Note that when value added coefficients are (correctly) computed as
% output - sum(intermediates in cif), then the computed components do not
% sum to total/bilateral exports. The residual accounts for the tariff
% expenses on intermediate goods which should not be treated as domestic
% value added. If there are no export subsidies, then the residual must be
% positive, i.e. the value added components account for equal or less than the
% value of exports.


% this file also computes value added exports as defined in Johnson &
% Noguera 2012, JIE



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% decomposition of TOTAL EXPORTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%
%   read data        %
%%%%%%%%%%%%%%%%%%%%%%
clear all

workdir = strcat('yourworkdir','/Repository');

cd(strcat(workdir,'/DescriptivesResults/Decomposition'))

mkdir bilateral

% number of sectors
s=33;
% number of regions
a=67;
% number of years
t=16;


% value added coefficient
data=dlmread('actual_vacoeff9611.txt');

r=zeros(s,a,t);

for c=1:t
    r(1:s,:,c)=data(s*c-(s-1):s*c,:);
end

clear data c


% value added coefficient for test: computed with fob io coefficients,
%i.e., treating tariff expenses on intermediates as domestic value added.
%Only if this version of the betas is used must the sum of the computed components
%equal total/bilateral exports

%{
data=dlmread('actual_trial_vacoeff9611.txt');
r=zeros(s,a,t);
for c=1:t
    r(1:s,:,c)=data(s*c-(s-1):s*c,:);
end
%}





% I-O tables
data=dlmread('actual_ioc9611.txt');


A=zeros(s*a,s*a,t);
% first dimension: sourcing country-sector
% second dimension: demanding country-sector

for j=1:t
  A(1:s*a,:,j)=data(s*a*j-(s*a-1):s*a*j,:);
end

% final demand
% first dimension: sourcing country-sector
% second dimension: demanding country
data=dlmread('actual_inv_final9611.txt');
c=zeros(s*a,a,t);

for j=1:t
    c(1:s*a,:,j)=data(s*a*j-(s*a-1):s*a*j,:);
end

clear data j





% gross export flows
data=dlmread('actual_exports_9611_noc.txt');

x=zeros(s,a,t);
xx = zeros(s*a,1,t);

for j=1:t
    x(1:s,:,j)=data(s*j-(s-1):s*j,:);
    xx(:,1,j)=reshape(x(:,:,j),[s*a,1,1]);
end
clear data j


% gross output: comes as row vector sorted as year country sector
data=dlmread('actual_output_9611.txt');

o = zeros(s*a,1,t);

for j=1:t
    o(1:a*s,1,j)=data((j-1)*s*a+1:s*a*j,1);
end

clear data j





% final demand including inventory
% first dimension: source country-sector
% second dimension: demanding country
data=dlmread('actual_inv_final9611.txt');
C=zeros(s*a,a,t);

for j=1:t
    C(1:s*a,:,j)=data(s*a*j-(s*a-1):s*a*j,:);
end

clear data





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DECOMPOSITION OF TOTAL EXPORTS OF A GIVEN SECTOR FROM A GIVEN COUNTRY %
% following Koopman et al. 2014 AER & Wang et al. 2013, NBER WP 19677
%%%% terms indices refer to Eq. 31 in Wang et al. 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14


% World Leontief scaled by va coefficient
% Leontief inverse of world input-output table for each year
B=zeros(s*a,s*a,t);

for j=1:t
  B(:,:,j) = inv(eye(a*s)-A(:,:,j));
end


vlong = reshape(r,[a*s,1,t]);

for j=1:t
    VB(:,:,j) = transpose( diag(vlong(:,:,j))*B(:,:,j) );
end


% set domestic final goods exports to zero -> cc

%cc=C;



I = eye(a);
I(11:14,11:14)=1;
Azc = kron(I,ones(s,1));  % the within China connections

cc = C.*(1-Azc); % set diagonal and intra-CHN flows to zero



% sum over importers to
% reshape final demand from
%       first dimension: sourcing country-sector
%       second dimension: demanding country
%       third dim: year

%to 
%       first dimension: sourcing country-sector
%       second dimension: year


y = zeros(a*s,1,t);

for j=1:t
    y(:,:,j) = cc(:,:,j)*ones(a,1);
end



%%%%%%%%%% country-sector va content -- TRANSPOSED structure as io tab
% columns: source sectors wi countries
% rows: demanding sectors wi countries (EXPORTERS)
%--> will be transposed below

VAFE = VB.*y; %domestic and foreign value added content of final goods exports




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% domestic value added content of intermediate goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% sum of terms 2 - 9 
%%%%%%%%%%%%%%%%%%%% double-counted term 9 will be substracted below


%%%%% total final goods output (exports plus domestic sales and inventory)


for j=1:t
    Y(:,:,j) = C(:,:,j)*ones(a,1);
end




% A-matrix without diagonals and intra-China

for j=1:t
    Az(:,:,j) = ones(a*s,a*s)-kron(I,ones(s));
end




Az=Az.*A;



for j=1:t
 AzBY(:,:,j) = Az(:,:,j)*B(:,:,j)*Y(:,:,j);
end



%domestic leontiefs on diagonal submatrics

L = zeros(a*s,a*s,t);

for j=1:t
    for i=1:a
        L( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j )  =   inv( eye(s) - A( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j ) );
    end
end




%% !!!! replace intra-CHN Leontief
for j=1:t
    L( 10*s+1:14*s,10*s+1:14*s,j) = inv(eye(4*s)-A(10*s+1:14*s,10*s+1:14*s,j));
end






% VB-type matrix based on domestic leontiefs only

for j=1:t
    VL(:,:,j) = transpose( diag(vlong(:,:,j))*L(:,:,j) );
end



VAIE9=VL.*AzBY; % domestic value added content of intermediate goods exports including returned domestic va and - at this stage, returned and reexported  va which is substracted below



%returned domestic va (terms 6-8)
for j=1:t
    BC(:,:,j)=B(:,:,j)*C(:,:,j);
end

for j=1:t
    for n = 1:a
        AzBYret((n-1)*s+1:n*s,1,j) = Az((n-1)*s+1:n*s,:,j)*BC(:,n,j);
    end
end



RDV = VL.*AzBYret; % returned domestic va





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% prep DOUBLE-COUNTED VA

%% TERMS 9 & 10: double counted domestic va



% Term 9

% matrix with total final goods export vectors on "diagonal"
for j=1:t
    for i=1:a
        ydiag((i-1)*s+1:i*s,i,j) = y((i-1)*s+1:i*s,1,j);
    end
end



% B-matrix without diagonals and without intra-China

Ih = eye(a); Ih(11:14,11:14) = 1;

for j=1:t
    Bz(:,:,j) = ones(a*s,a*s)-kron(Ih,ones(s));
end

Bz=Bz.*B;



for j=1:t
    ABzy(:,:,j) = Az(:,:,j)*Bz(:,:,j)*ydiag(:,:,j);   % potentially there is an error here: Bz instead of B
end



%set non-diagonal vectors = zero and write in column vector

ABzys = zeros(a*s,1,t);
for j=1:t
    for i=1:a
        ABzys( (i-1)*s+1:i*s,1,j) = ABzy((i-1)*s+1:i*s,i,j);
    end
end


DCDVAE9 = VL.*ABzys;   % double-counted domestic value added caused by final goods exports
VAIE=VAIE9-DCDVAE9;  %domestic va in intermediate exports net of double counting


% term 10:

for j=1:t
    Azo(:,:,j) =Az(:,:,j)*o(:,:,j);
end




% B with diagonal blocks only (and intra-CHN)

Bd = B-Bz;


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end

DCDVAE10 = (VBd-VL).*Azo;

DCDVAE=DCDVAE9+DCDVAE10;
clear DCDVAE9 DCDVAE10

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% double-counted foreign value added content of exports %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% TERMS 13 & 16: double counted foreign va


%premultiply total exports xx by domestic leontief

Lye=zeros(s*a,1,t);
for j=1:t
    Lye(:,:,j) = L(:,:,j)*xx(:,:,j);
end


%sum over final countries
Azye=zeros(s*a,1,t);
for j=1:t
    Azye(:,1,j)=Az(:,:,j)*Lye(:,:,j);
end




% VB-type matrix based on B zero

for j=1:t
    VBz(:,:,j) = transpose( diag(vlong(:,:,j))*Bz(:,:,j) );
end


DCFVAE = VBz.*Azye;  % double-counted foreign value added




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% foreign value added %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% terms 12 and 15 (structure identical to 13 & 16)



% domestic final demand (including inventory)

    cD =C-cc ;  %setting off-diagonal except intra-China flows equal to zero


yd = zeros(a*s,1,t);
for j=1:t
    yd(:,:,j) = cD(:,:,j)*ones(a,1);
end




%premultiply total domestic final good absorption by domestic leontief

Lyd=zeros(s*a,1,t);
for j=1:t
    Lyd(:,:,j) = L(:,:,j)*yd(:,:,j);
end


%sum over final countries
Azyd=zeros(s*a,1,t);
for j=1:t
    Azyd(:,1,j)=Az(:,:,j)*Lyd(:,:,j);
end


FVAE = VBz.*Azyd;  % double-counted foreign value added



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% transpose - source in rows, exporters in columns -> same element
% intepretation as in world input-output table


for j=1:1:t
    VAFE(:,:,j)=VAFE(:,:,j)';
    VAIE(:,:,j)=VAIE(:,:,j)';
    FVAE(:,:,j)=FVAE(:,:,j)';
    DCDVAE(:,:,j)=DCDVAE(:,:,j)';
    DCFVAE(:,:,j)=DCFVAE(:,:,j)'; 
        RDV(:,:,j)=RDV(:,:,j)';  
end



%total value added in exports:
TVAE = VAFE + VAIE + FVAE  + DCDVAE + DCFVAE ;
% RDV is included in VAIE


VAFE_t=[];VAIE_t=[];DCDVAE_t=[];DCFVAE_t=[];FVAE_t=[];RDV_t=[];

for j=1:1:t
    VAFE_t=[VAFE_t; VAFE(:,:,j)];
    VAIE_t=[VAIE_t; VAIE(:,:,j)];
    DCDVAE_t=[DCDVAE_t; DCDVAE(:,:,j)];
    DCFVAE_t=[DCFVAE_t; DCFVAE(:,:,j)];
    FVAE_t=[FVAE_t; FVAE(:,:,j)];
    RDV_t=[RDV_t; RDV(:,:,j)];

end

dlmwrite('VAFE.txt',VAFE_t);
dlmwrite('VAIE.txt',VAIE_t);
dlmwrite('FVAE.txt',FVAE_t);
dlmwrite('DCDVAE.txt',DCDVAE_t);
dlmwrite('DCFVAE.txt',DCFVAE_t);
dlmwrite('RDV.txt',RDV_t);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% domestic value added content of exports for DVA ratio
%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


DV = VAFE + VAIE + FVAE;
DVDC = VAFE + VAIE + DCDVAE +  DCFVAE + FVAE;

clear VAFE VAIE DCDVAE FVAE DCFVAE

Az = kron(eye(a),ones(s,s));
Az(10*s+1:14*s,10*s+1:14*s)=1;  % the within China connections

DV = Az.*DV; %set source! = exporter -> zero
DVDC = Az.*DVDC;

DV = sum(DV,1); % sum over source sectors
DVDC = sum(DVDC,1); % sum over source sectors

DV=squeeze(DV);
DVDC=squeeze(DVDC);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%% VAX for VAX RATIO as defined in Johnson & Noguera 2012, JIE %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% destination-specific domestic value added exports  %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

VX=[];


for j=1:t
    k = 1995+j;
    
VAFE_bh=[]; 

 for h = 1:a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports to h %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14

y_h = [zeros((h-1),1); 1 ; zeros((a-h),1) ];

%final goods export to destination x

    y_b(:,:) = C(:,:,j)*y_h;

%y_h = [zeros((11-1)*s,1); ones(s,1) ; zeros((a-11)*s,1) ];

VAFE_b = VB(:,:,j).*y_b; %domestic and foreign value added content of final goods exports

VAFE_b=VAFE_b';


VAFE_bh = cat(3,VAFE_bh,VAFE_b);


end


VAFE = squeeze(sum(VAFE_bh,2)); %squeeze removes singleton dimension

I = eye(a); I(11:14,11:14)=1; %set countries fg exports to themselves =0 and set all Chinas' fg exports to the other Chinas = 0

he = 1-kron(I,ones(s,1));

VAX = VAFE.*he*ones(a,1);

VX = [VX VAX];

end



for i=1:a
    for j=1:s
        DV((i-1)*s+j,t+1)=j;
        VX((i-1)*s+j,t+1)=j;
    end
end

for i=1:a
   DV((i-1)*s+1:i*s,t+2)=i;
   VX((i-1)*s+1:i*s,t+2)=i;
end

dlmwrite('DV9611.txt',DV)
dlmwrite('VAX9611.txt',VX)




clearvars -except C VB A B Y VL ydiag o VBd Lye VBz Lyd j s t i a

save bilateral/deco_actICIO9611_totexp_input





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% decomposition of BILATERAL EXPORTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  this code generates BILATERAL EXPORTS TO h FROM A GIVEN SECTOR FROM A GIVEN COUNTRY DECOMPOSED INTO six VA types%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear
load bilateral/deco_actICIO9611_totexp_input   

a=i; %#countries

t=16;
%make new directory for every year

for j=1:t
    k = 1995+j;
    mkdir(['bilateral/' int2str(k)])
end




% individual export destinations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% destination-specific domestic and foreign va content %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for j=1:t
    k = 1995+j;
    


VAFE_bh=[]; VAIE_bh= []; FVAE_bh =[]; DCDVAE_bh =[];  DCFVAE_bh=[];

    



for h = 1:a
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports to x %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14

y_h = [zeros((h-1),1); 1 ; zeros((a-h),1) ];

%final goods export to destination x

    y_b(:,:) = C(:,:,j)*y_h;

%y_h = [zeros((11-1)*s,1); ones(s,1) ; zeros((a-11)*s,1) ];

VAFE_b = VB(:,:,j).*y_b; %domestic and foreign value added content of final goods exports

VAFE_b=VAFE_b';



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% domestic value added content of intermediate goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% sum of terms 2 - 9 
%%%%%%%%%%%%%%%%%%%% double-counted term 9 will be substracted below


% A-matrix without diagonals and for single destination country only

A_h = [zeros(a*s,(h-1)*s), ones(a*s,s), zeros(a*s,(a-h)*s)];
Az_b=A(:,:,j).*A_h; %use Az instead of A to set "domestic exports" to zero



 AzBY_b(:,:) = Az_b(:,:)*B(:,:,j)*Y(:,:,j);


VAIE9_b=VL(:,:,j).*AzBY_b; % domestic value added content of intermediate goods exports including returned domestic va and - at this stage, returned and reexported  va which is substracted below





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% prep DOUBLE-COUNTED VA

%% TERMS 9 & 10: double counted domestic va


% Term 9


    ABzy_b(:,:) = Az_b(:,:)*B(:,:,j)*ydiag(:,:,j);   % potentially there is an error: Bz instead of B



%set non-diagonal vectors = zero and write in column vector

ABzys_b = zeros(a*s,1);
    for i=1:a
        ABzys_b( (i-1)*s+1:i*s,1) = ABzy_b((i-1)*s+1:i*s,i);
    end

    
%% !!!

%ABzys_b()
    

DCDVAE9_b = VL(:,:,j).*ABzys_b;   % double-counted domestic value added caused by final goods exports

VAIE_b=VAIE9_b-DCDVAE9_b;  %domestic va in intermediate exports net of double counting
VAIE_b=VAIE_b';


clear VAIE9_b


% term 10:


    Azo_b(:,:) =Az_b(:,:)*o(:,:,j);


DCDVAE10_b = (VBd(:,:,j)-VL(:,:,j)).*Azo_b(:,:);

DCDVAE_b = DCDVAE9_b+DCDVAE10_b;
DCDVAE_b =DCDVAE_b';

clear DCDVAE9_b DCDVAE10_b

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% double-counted foreign value added content of exports %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% TERMS 13 & 16: double-counted foreign va



%sum over final countries


    Azye_b(:,1)=Az_b(:,:)*Lye(:,:,j);


DCFVAE_b = VBz(:,:,j).*Azye_b(:,:);  % double-counted foreign value added

DCFVAE_b = DCFVAE_b';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% foreign value added %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% terms 12 and 15 (structure identical to 13 & 16)



%sum over final countries


    Azyd_b(:,1)=Az_b(:,:)*Lyd(:,:,j);



FVAE_b = VBz(:,:,j).*Azyd_b(:,:);  % double-counted foreign value added
FVAE_b =FVAE_b';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

VAFE_bh = cat(3,VAFE_bh,VAFE_b);
VAIE_bh = cat(3,VAIE_bh,VAIE_b);
FVAE_bh = cat(3,FVAE_bh,FVAE_b);
DCDVAE_bh = cat(3,DCDVAE_bh,DCDVAE_b);
DCFVAE_bh = cat(3,DCFVAE_bh,DCFVAE_b); % note that third dimension is now destination country h

clear VAFE_b  VAIE_b  FVAE_b  DCDVAE_b   DCFVAE_b Az_b AzBY_b ABzy_b ABzys_b Azo_b Azye_b Azyd_b
end





%%%% -> saving takes most of the time, matlab computing is rapid -> save
%%%% only what's necessary!!


 f = fullfile(['bilateral/' int2str(k)],'VAFE_bh.mat');
 % f1 = fullfile(['bilateral/' int2str(k)],'VAFE_bh.txt');
  % f2 = fullfile(['bilateral/' int2str(k)],'VAIE_bh.txt');
 % f3 = fullfile(['bilateral/' int2str(k)],'FVAE_bh.txt');
 %  f4 = fullfile(['bilateral/' int2str(k)],'DCDVAE_bh.txt');
 % f5 = fullfile(['bilateral/' int2str(k)],'DCFVAE_bh.txt');
save(f, 'VAFE_bh','-v7.3')
 %save(f, 'VAFE_bh',  'VAIE_bh',  'FVAE_bh',   'DCDVAE_bh',   'DCFVAE_bh','-v7.3')
  %dlmwrite(f1,VAFE_bh); dlmwrite(f2,VAIE_bh); dlmwrite(f3,FVAE_bh); dlmwrite(f4,DCDVAE_bh); dlmwrite(f5,DCFVAE_bh);
%     
%     
% 
% VAFE_bhl=reshape(VAFE_bh,[a*s*a*s,1,a]);
% VAIE_bhl=reshape(VAIE_bh,[a*s*a*s,1,a]);
% FVAE_bhl=reshape(FVAE_bh,[a*s*a*s,1,a]);
% DCDVAE_bhl=reshape(DCDVAE_bh,[a*s*a*s,1,a]);
% DCFVAE_bhl=reshape(DCFVAE_bh,[a*s*a*s,1,a]);
% 
% 
%     f1 = fullfile(['bilateral/' int2str(k)],'VAFE_bhl.txt');
%     f2 = fullfile(['bilateral/' int2str(k)],'VAIE_bhl.txt');
%     f3 = fullfile(['bilateral/' int2str(k)],'FVAE_bhl.txt');
%     f4 = fullfile(['bilateral/' int2str(k)],'DCDVAE_bhl.txt');
%     f5 = fullfile(['bilateral/' int2str(k)],'DCFVAE_bhl.txt');
% 
%     dlmwrite(f1,VAFE_bhl); dlmwrite(f2,VAIE_bhl); dlmwrite(f3,FVAE_bhl); dlmwrite(f4,DCDVAE_bhl); dlmwrite(f5,DCFVAE_bhl);
% 
%     
%     
end











