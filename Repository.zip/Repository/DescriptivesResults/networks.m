


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Supply & Demand networks for baseline & counterfactual  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

workdir = strcat('yourworkdir','/Repository');

cd(strcat(workdir))



%%% networks> tariff counterfactuals CP HB elasticities

load 'Simulation/Counterfactuals/WTOCHN2007OC/deco/0/VAFE_bh'
vafe0 = squeeze(sum(VAFE_bh,3));


load 'Simulation/Counterfactuals/WTOCHN2007OC/deco/1/VAFE_bh'
vafep = squeeze(sum(VAFE_bh,3));

VAFE = cat(3,vafe0,vafep);

t=2;
N=67;
J=33;

% supply networks

SN=zeros(N,N*J,t);

for s=1:N
   SN(s,:,:) = sum(VAFE( (s-1)*J+1:s*J  ,:,:));
end

S = sum(SN);
sn = SN./S;


% demand networks: collapse demand sectors

DN=zeros(N*J,N,t);

for s=1:N
   DN(:,s,:) = sum(VAFE(:,(s-1)*J+1:s*J,:),2);
end

D = sum(DN,2);
dn = DN./D;

dnl = [];
for l=1:t
    dnl = [dnl; DN(:,:,l)];
end

snl = [];
for l=1:t
    snl = [snl; SN(:,:,l)];
end


dlmwrite('Simulation/Counterfactuals/WTOCHN2007OC/dnlca.txt',dnl)
dlmwrite('Simulation/Counterfactuals/WTOCHN2007OC/snlca.txt',snl)





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%**
%%%%%%%%%%%%%%%%% Supply & Demand networks for all years in ICIO database  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%**




clear all
cd './DescriptivesResults/Decomposition'


J = 33;
N = 67;
t = 16;




VAFE = [];

for j=1:t
    k = 1995+j;
    
f = fullfile(['bilateral/' int2str(k)],'VAFE_bh.mat');
load(f, 'VAFE_bh')
    
vafe = squeeze(sum(VAFE_bh,3)); %sum over VA destinations and remove singleton dimension: rows are now VA source sectors and cols are final goods exporters

VAFE = cat(3,VAFE,vafe);

end

clear vafe VAFE_bh




% supply networks: collapse source sectors 

SN=zeros(N,N*J,t);

for s=1:N
   SN(s,:,:) = sum(VAFE( (s-1)*J+1:s*J  ,:,:));
end

S = sum(SN);
sn = SN./S;


% demand networks: collapse demand sectors

DN=zeros(N*J,N,t);

for s=1:N
   DN(:,s,:) = sum(VAFE(:,(s-1)*J+1:s*J,:),2);
end

D = sum(DN,2);
dn = DN./D;

%save SNDN

%load SNDN


% export the absolute flows, not the shares
dnl = [];
for l=1:t
    dnl = [dnl; DN(:,:,l)];
end

snl = [];

for l=1:t
    snl = [snl; SN(:,:,l)];
end


dlmwrite('dnl.txt',dnl)
dlmwrite('snl.txt',snl)

