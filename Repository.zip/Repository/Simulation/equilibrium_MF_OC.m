% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%  Main Program Counterfactuals
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [wf0 pfm0 pff0 PQm PQf Fmp Ffp Dimp Difp Ws krit] = equilibrium_LM(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor) %note that originally ***SIn*** was not in this place and VP is also new

% initialize vectors of ex-post wage and price factors 
 wf0      =  ones(N,1);  pfm0      =  ones(J,N); pff0      =  ones(J,N);

%wf0      =  ones(N,1); 
%pf0      =  ones(J,N);

for n=1:1:20
    wf0(n,1)=1;
end
for n=21:1:N
    wf0(n,1)=1;
end


 Ws=wf0;
 
 krit=1;
 
 
 wfmax = 1; e = 1;
while (e <= maxit) && (wfmax > tol);

[pfm0 pff0 c] = PH_MF(wf0,taum_hat,tauf_hat,T,B,G,Dim,Dif,J,N,maxit,tol);
       
% Calculating trade shares
Dimp = Dinprime(Dim,taum_hat,c,T,J,N);
Difp = Dinprime(Dif,tauf_hat,c,T,J,N);

Dimp_om = Dimp./taump;
Difp_om = Difp./taufp;


for j   = 1:1:J
irow    = 1+N*(j-1):1:N*j;
Fmp(j,:) = sum((Dimp(irow,:)./taump(irow,:))');
Ffp(j,:) = sum((Difp(irow,:)./taufp(irow,:))');
end
 
% % Expenditure MATRIX
[PQm PQf] = expenditure_MF(alphas,B,G,Dimp,Difp,taump,taufp,Fmp,Ffp,VAn,wf0,SIn,VP,J,N); %note that originally there was ***Sn*** in this place
% expenditures Xji in long vector: PQ_vec=(X11 X12 X13...)' 
% expenditures Xji in long vector: PQ_vec=(X11 X12 X13...)' 
PQm_vec   = reshape(PQm',1,J*N)'; 
PQf_vec   = reshape(PQf',1,J*N)'; 


for n = 1:1:N
    DPm(:,n)  = Dimp_om(:,n).*PQm_vec; 
    DPf(:,n)  = Difp_om(:,n).*PQf_vec; 
end

LHS = sum(DPm)'+sum(DPf)'; %exports

% calculating RHS (Imports) trade balance
PFm = PQm.*Fmp;
PFf = PQf.*Ffp;
RHS = sum(PFm)'+sum(PFf)'; %imports

%excess function for CHN aggregate

II = eye(N);
OC = [ II(1:10,:); sum(II(11:14,:),1);II(15:N,:)]; % multiplying column vector with OC summs the four Chinas (transforms N-dim vector into N-3 dim vector)

RHS = OC*RHS;
LHS = OC*LHS;
SnOC = OC*Sn;
VAOC = OC*VAn;

% excess function (trade balance)
ZW2 = -(RHS - LHS + SnOC)./(abs(VAOC)); % In the most recent version of IHRA we used gdp as scaling factor

% transforms ZW2 back to a N-dim vector where all Chinas get the same zw
ZW2 = OC'*ZW2;

%Iteration factor prices
wf1 =wf0.*(1-vfactor*ZW2./wf0);

wfmax=sum(abs(wf1-wf0));

disp(['wage tolerance = ' num2str(sum(abs(wf1-wf0)))])
%disp(wf0(7,1))
%disp(wf0(26,1))
wfmax0 = wfmax;
wf0=(wf1);

%matrix that collects the wage series during the convergence process...
Ws=horzcat(Ws,wf1);
%vector that collects the corresponding tolerance (to find the minimum
%later)
krit=horzcat(krit,wfmax);
disp(e);

e=e+1;
end

