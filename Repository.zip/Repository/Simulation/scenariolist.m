

if e == 1
    folder = 'WTOCHN2007OC'; file = 'WTOCHN2007OC.mat';
end


if e == 2
    folder = 'CostShares'; file = 'CS2007OC.mat';
end

if e == 3
    folder = 'test_noPr/newbase'; file = 'newbaseOC.mat';
end

if e == 4  %% DO NOT CHANGES THIS NUMBER UNLESS ADJUSTING ALSO cf_results.m (special baseline)%%
    folder = 'test_noPr/WTOCHN2007OC'; file = 'WTOCHN2007OC.mat';
end


if e == 5
    folder = 'global_tariffs'; file = 'WTOCHN2007OC.mat';
end



if e == 6
    folder = 'nomore_tariffs'; file = 'WTOCHN2007OC.mat';
end


if e == 7
    folder = 'Betas'; file =  'CS2007OC.mat' ;
end

if e == 8
    folder = 'transportCost'; file = 'WTOCHN2007OC.mat';
end

if e == 9
    folder = 'rta_wto_tau_nop'; file = 'WTOCHN2007OC.mat';
end

if e == 10
    folder = 'wto_dummy_CPHB995_nop'; file = 'WTOCHN2007OC.mat';
end

if e == 11
    folder = 'wto_dummy_CPHB995_nop_rob'; file = 'WTOCHN2007OC.mat';
end

if e == 12
    folder = 'thetasBWUSA99'; file = 'WTOCHN2007OC.mat';
end


if e == 13
    folder = 'equal_thetas'; file = 'WTOCHN2007OC.mat';
end


if e == 14
    folder = 'one_theta'; file = 'WTOCHN2007OC.mat';
end




if e == 103
    folder = 'ChangesSI'; file = 'WTOCHN2007OC.mat';
end


if e == 102
    folder = 'allChangesS'; file = 'WTOCHN2007OC.mat';
end


if e == 101 %note that baseline for this scenario is computed separately %note that results for this scenario must be computed with  separate cf_results_va.m file
    folder = 'OOC'; file = 'WTOCHN2007OOC.mat';
end










