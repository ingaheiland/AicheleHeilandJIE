% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Generation of datasets with initial conditions % 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

workdir = strcat('yourworkdir','/Repository');

cd(strcat(workdir,'/Simulation'))


close all
clear all
clc

N = 67;
J = 33;


% expenditure shares
alphas=importdata('Baseline/alphas.txt');

% value added cost shares
B=importdata('Baseline/B.txt');

% input-output matrix
G=importdata('Baseline/G.txt');

% initial trade share matrix interm. goods
Dim=importdata('Baseline/Dim2000.txt');

% initial trade share matrix final goods
Dif=importdata('Baseline/Dif2000.txt');

% value added
VAn=importdata('Baseline/VA_n.txt');

% trade imbalance (net exports) + net inventory stock increase
SIn=importdata('Baseline/SI_n.txt');

% trade imbalance (net exports) only
Sn=importdata('Baseline/S_n.txt');

% expenditure
Xm0=importdata('Baseline/Xm0.txt');
Xf0=importdata('Baseline/Xf0.txt');

% trade tariff weighted shares
Fm=importdata('Baseline/Fm.txt');
Ff=importdata('Baseline/Ff.txt');



% inventory data
Inv=importdata('Baseline/inventory2000.txt');


% sectoral demand for inventory changes
VP=importdata('Baseline/VP.txt');

save 'initial_condition_2000'









 % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Generation of dataset initial conditions for robustness test in 
%   Table 4 row j
%    
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear all
clc

N = 64;
J = 33;


% expenditure shares
alphas=importdata('OPI/alphas.txt');

% value added cost shares
B=importdata('OPI/B.txt');

% input-output matrix
G=importdata('OPI/G.txt');

% initial trade share matrix
Din=importdata('OPI/Din2000.txt');

% value added
VAn=importdata('OPI/VA_n.txt');

% trade imbalance (net exports) + net inventory stock increase
SIn=importdata('OPI/SI_n.txt');

% trade imbalance (net exports) only
Sn=importdata('OPI/S_n.txt');

% expenditure
X0=importdata('OPI/X0.txt');

% trade tariff weighted shares
F=importdata('OPI/F.txt');

% inventory data
Inv=importdata('OPI/inventory2000.txt');

% sectoral demand for inventory changes
VP=importdata('OPI/VP.txt');

save 'initial_condition_2000_OPI'




 % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Generation of dataset initial conditions for robustness test in 
%   Table 4 row i
%    
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear all
clc

N = 64;
J = 33;


% expenditure shares
alphas=importdata('OOC/alphas.txt');

% value added cost shares
B=importdata('OOC/B.txt');

% input-output matrix
G=importdata('OOC/G.txt');

% initial trade share matrix interm. goods
Dim=importdata('OOC/Dim2000.txt');

% initial trade share matrix final goods
Dif=importdata('OOC/Dif2000.txt');

% value added
VAn=importdata('OOC/VA_n.txt');

% trade imbalance (net exports) + net inventory stock increase
SIn=importdata('OOC/SI_n.txt');

% trade imbalance (net exports) only
Sn=importdata('OOC/S_n.txt');

% expenditure
Xm0=importdata('OOC/Xm0.txt');
Xf0=importdata('OOC/Xf0.txt');

% trade tariff weighted shares
Fm=importdata('OOC/Fm.txt');
Ff=importdata('OOC/Ff.txt');



% inventory data
Inv=importdata('OOC/inventory2000.txt');



% sectoral demand for inventory changes
VP=importdata('OOC/VP.txt');


save 'initial_condition_2000_OOC'









