
clear all

workdir = strcat('yourworkdir','/Repository');

cd(strcat(workdir,'/Simulation'))



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Main Program Counterfactuals
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CP elasticities alike Handbook chapter



close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000

T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;




tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO  

taump = taum2007;
taufp = tauf2007;



taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 



[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals WTOCHN2007OC

save 'Counterfactuals/WTOCHN2007OC/WTOCHN2007OC'


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% WTO DUMMY 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 4, row b

    close all
    clear all
    clc

    vfactor  = -.1;
    tol      = 1E-12;
    maxit    = 500;

    load initial_condition_2000
    T=importdata('Baseline/thetasCPHB.txt');
    T = -T;
    T = 1./T;


tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO  


    taump = taum2007;
    taufp = tauf2007;



    % trade cost changes due to WTO entry
    kpa_hat=importdata('Counterfactuals/est_CPHB995rta_wto_nop.txt');                       % tariffs 2007 w CHN in WTO  


    taum_hat=taump./taum.*kpa_hat;                                           
    tauf_hat=taufp./tauf.*kpa_hat;                                          


    [wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

    mkdir ./Counterfactuals wto_dummy_CPHB995_nop
    save 'Counterfactuals/wto_dummy_CPHB995_nop/WTOCHN2007OC'
    
    
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% WTO DUMMY  w/o neg sig estimates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Table 4, row c  
        
    close all
    clear all
    clc

    vfactor  = -.1;
    tol      = 1E-12;
    maxit    = 500;

    load initial_condition_2000
    T=importdata('Baseline/thetasCPHB.txt');
    T = -T;
    T = 1./T;


tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO  

    taump = taum2007;
    taufp = tauf2007;



    % trade cost changes due to WTO entry
    kpa_hat=importdata('Counterfactuals/est_CPHB995rta_wto_nop_rob.txt');                       % tariffs 2007 w CHN in WTO  


    taum_hat=taump./taum.*kpa_hat;                                           
    tauf_hat=taufp./tauf.*kpa_hat;                                          


    [wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

    mkdir ./Counterfactuals wto_dummy_CPHB995_nop_rob

    save 'Counterfactuals/wto_dummy_CPHB995_nop_rob/WTOCHN2007OC'
    
    


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%% ROBUSTNESS THETAS
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
 % Table 4, row d   
    
 %%% Broda & Weinstein, cut-off 99% largest elasticities, US trade weights
 
    
close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000

T=importdata('Counterfactuals/thetasBWUSA99.txt');
T = -T;
T = 1./T;

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO  

taump = taum2007;
taufp = tauf2007;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 



[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals thetasBWUSA99
save 'Counterfactuals/thetasBWUSA99/WTOCHN2007OC'
    
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% robustness identical trade elasticities (Egger et al) &&&&&&&&&&&&&
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 4, row e

close all
clear all
clc

vfactor  = -.2;
tol      = 1E-12;
maxit    = 1000;

load initial_condition_2000

%%%
T= [6.9849*ones(18,1); 4.9591*ones(15,1) ];
T = 1./T;
%%

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO  

taump = taum2007;
taufp = tauf2007;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 


 
[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals equal_thetas
save 'Counterfactuals/equal_thetas/WTOCHN2007OC'




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% robustness one trade elasticity == 5  &&&&&&&&&&&&&
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 4, row f



close all
clear all
clc

vfactor  = -.2;
tol      = 1E-12;
maxit    = 1000;

load initial_condition_2000


%%%
T = 1/5*ones(33,1);
%%

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO  

taump = taum2007;
taufp = tauf2007;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 



[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals one_theta
save 'Counterfactuals/one_theta/WTOCHN2007OC'






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% Robustness Model %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Robustness: what if the processing sector gets no special treatment
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;   % set low tol level to make sure we start from a "good" new baseline
maxit    = 1000;

load initial_condition_2000
    T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  simulate first a new counterfactual baseline w/o the processing sector's exemptions %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 4, row g


tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

taump = tauf; % taufp is identical to taump - except for the processing sector
taufp = tauf;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 

 
%% the One-China model

[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC


mkdir ./Counterfactuals/test_noPr newbase
save 'Counterfactuals/test_noPr/newbase/newbaseOC'


% for Table 4, row h


% new baseline
Dif = Difp_all;
Dim = Dimp_all;
Ff = Ffp_all;
Fm = Fmp_all;
Xf0 = PQf_all;
Xm0 = PQm_all;
VAn=wf0_all.*VAn;





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Effects of tariff changes 2000 - 2007 from China's accession to WTO %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum = tauf;

tauf2007=importdata('Counterfactuals/ftariffs_cf2007.txt');                       % tariffs 2007 w CHN in WTO 

taufp = tauf2007;
taump = tauf2007;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 

tol      = 1E-12;  % set tol back to standard level for comparability 

 
%% the One-China model

[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals/test_noPr WTOCHN2007OC
save 'Counterfactuals/test_noPr/WTOCHN2007OC/WTOCHN2007OC'









% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   ONLY ONE CHINA: aggregated sectors%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 4, row i

close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000_OOC
N = 64;


T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;


tauf=importdata('OOC/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('OOC/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_cf2007_OOC.txt');                       % tariffs 2007 w CHN in WTO 
taum2007=importdata('Counterfactuals/mtariffs_cf2007_OOC.txt');                       % tariffs 2007 w CHN in WTO  

taump = taum2007;
taufp = tauf2007;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 

 
[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals OOC
save 'Counterfactuals/OOC/WTOCHN2007OOC'






% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   ONLY ONE PI: no difference in trade shares + aggregated sectors%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 4, row j


close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000_OPI
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;


tau=importdata('OPI/tariffs2000.txt');                       % tariffs 2000  

taup2007=importdata('Counterfactuals/tariffs_cf2007_OPI.txt');                       % tariffs 2007 w CHN in WTO 

taup = taup2007;

tau_hat=taup./tau;                                           % Change in tariffs 
 

[wf0_all pf0_all PQ_all Fp_all Dinp_all Ws_all krit] = equilibrium_LC_i(tau_hat,taup,alphas,T,B,G,Din,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC


mkdir ./Counterfactuals OPI
save 'Counterfactuals/OPI/WTOCHN2007OPI'









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% ADDITIONAL SCENARIOS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    More scenarios: global tariffs decline to zero     %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row b


close all
clear all
clc

vfactor  = -.02;
tol      = 1E-12;
maxit    = 5000;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;


tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

taufp=tauf; taufp(:,:)=1;                      % tariffs 2007 w CHN in WTO 
taump=taum; taump(:,:)=1;                       % tariffs 2007 w CHN in WTO  

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 



[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals nomore_tariffs
save 'Counterfactuals/nomore_tariffs/WTOCHN2007OC'





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    More scenarios: global tariff decline  2000 - 2007 %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row c


close all
clear all
clc

vfactor  = -.02;
tol      = 1E-12;
maxit    = 5000;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_global_cf2007.txt');                      
taum2007=importdata('Counterfactuals/mtariffs_global_cf2007.txt');                        

taump = taum2007;
taufp = tauf2007;


taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals global_tariffs
save 'Counterfactuals/global_tariffs/WTOCHN2007OC'





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    More scenarios: global tariff RTA entry, WTO entry, and tariff decline  2000 - 2007 - nop %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row d


close all
clear all
clc

vfactor  = -.02;
tol      = 1E-12;
maxit    = 5000;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_global_cf2007.txt');                       
taum2007=importdata('Counterfactuals/mtariffs_global_cf2007.txt');                       

taump = taum2007;
taufp = tauf2007;



% trade cost changes due to WTO entry
kpa_hat=importdata('Counterfactuals/CPHBwto_ta_entry_nop.txt');                        


taum_hat=taump./taum.*kpa_hat;                                           
tauf_hat=taufp./tauf.*kpa_hat;                                          


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals rta_wto_tau_nop
save 'Counterfactuals/rta_wto_tau_nop/WTOCHN2007OC'





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    More scenarios: transportation cost change   2000 - 2007 %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row e

close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

taump = taum;
taufp = tauf;

% trade cost changes due to WTO entry
kpa_hat=importdata('Counterfactuals/tchat2007.txt');                         


taum_hat=taump./taum.*kpa_hat;                                           
tauf_hat=taufp./tauf.*kpa_hat;                                          


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals transportCost
save 'Counterfactuals/transportCost/WTOCHN2007OC'








% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Robustness Cost Shares
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row g

close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;


% expenditure shares
alphas=importdata('Counterfactuals/alphas2007.txt');

% value added cost shares
B=importdata('Counterfactuals/B2007.txt');

% input-output matrix
G=importdata('Counterfactuals/G2007.txt');

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

taump = taum;
taufp = tauf;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir Counterfactuals CostShares
save 'Counterfactuals/CostShares/CS2007OC'






% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Robustness Betas
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row f

close all
clear all
clc

vfactor  = -.1;
tol      = 1E-12;
maxit    = 500;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;

% value added cost shares
B=importdata('Counterfactuals/B2007.txt');

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

taump = taum;
taufp = tauf;

taum_hat=taump./taum;                                           % Change in tariffs 
tauf_hat=taufp./tauf;                                           % Change in tariffs 


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals Betas
save 'Counterfactuals/Betas/CS2007OC'





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    More scenarios: =changes in SN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row h


close all
clear all
clc

vfactor  = -.02;
tol      = 1E-7;
maxit    = 5000;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;



% trade imbalance (net exports) + net inventory stock increase
SIn=importdata('Counterfactuals/SI_2007.txt');

% trade imbalance (net exports) only
Sn=importdata('Counterfactuals/S_2007.txt');

% sectoral demand for inventory changes
VP=importdata('Counterfactuals/VP2007.txt');

% sectoral  inventory changes
Inv=importdata('Counterfactuals/inventory2007.txt');

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

taump = taum;
taufp = tauf;

taum_hat=taump./taum;                                           
tauf_hat=taufp./tauf;                                          


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals ChangesSI
save 'Counterfactuals/ChangesSI/WTOCHN2007OC'





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    More scenarios: all observed changes incl. SN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Table 5, row i


close all
clear all
clc

vfactor  = -.02;
tol      = 1E-7;
maxit    = 5000;

load initial_condition_2000
T=importdata('Baseline/thetasCPHB.txt');
T = -T;
T = 1./T;


%technology

% expenditure shares
alphas=importdata('Counterfactuals/alphas2007.txt');

% value added cost shares
B=importdata('Counterfactuals/B2007.txt');

% input-output matrix
G=importdata('Counterfactuals/G2007.txt');

% trade imbalance (net exports) + net inventory stock increase
SIn=importdata('Counterfactuals/SI_2007.txt');

% trade imbalance (net exports) only
Sn=importdata('Counterfactuals/S_2007.txt');

% sectoral demand for inventory changes
VP=importdata('Counterfactuals/VP2007.txt');

% sectoral  inventory changes
Inv=importdata('Counterfactuals/inventory2007.txt');

tauf=importdata('Baseline/ftariffs2000.txt');                       % tariffs 2000  
taum=importdata('Baseline/mtariffs2000.txt');                       % tariffs 2000  

tauf2007=importdata('Counterfactuals/ftariffs_global_cf2007.txt');                      
taum2007=importdata('Counterfactuals/mtariffs_global_cf2007.txt');                       

taump = taum2007;
taufp = tauf2007;

% trade cost changes due to WTO and RTA entry
kpa_hat=importdata('Counterfactuals/CPHBwto_ta_entry_nop.txt');                       

% transportation cost
kpa_hat2=importdata('Counterfactuals/tchat2007.txt');                      

kpa_hat=kpa_hat.*kpa_hat2;




taum_hat=taump./taum.*kpa_hat;                                           
tauf_hat=taufp./tauf.*kpa_hat;                                          


[wf0_all pfm0_all pff0_all PQm_all PQf_all Fmp_all Ffp_all Dimp_all Difp_all Ws_all krit] = equilibrium_MF_OC(taum_hat,tauf_hat,taump,taufp,alphas,T,B,G,Dim,Dif,J,N,maxit,tol,VAn,SIn,Sn,VP,vfactor); %add wstart for use with equilibrium_LC

mkdir ./Counterfactuals allChangesS
save 'Counterfactuals/allChangesS/WTOCHN2007OC'








