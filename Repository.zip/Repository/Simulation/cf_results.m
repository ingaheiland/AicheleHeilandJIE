
%%% this code converts and processes MATLAB output for all scenarios to
%%% .txt-files

clear all


workdir = strcat('yourworkdir','/Repository');

parent = strcat(workdir,'/Simulation');
home = strcat(workdir,'/Simulation/Counterfactuals');



%% e indexes scenarios in scenariolist.m
for e= 1:14 % can also set vector e = [1 12] ...

run(fullfile(parent,'scenariolist'))
fn = fullfile(home,folder,file);
cd(fileparts(fn))

load(fn)
    
    
A_base=importdata(fullfile(parent,'Baseline','ioc2000.txt'));

if (e>1)
    load(fullfile(home,'WTOCHN2007OC/deco','DVAR.mat'),'VX') 
end

if (e==1)
    VX=[];
end

if (e == 4)
    load(fullfile(home,'test_noPr/newbase/deco','DVAR.mat'),'VX')
    load(fullfile(home,'test_noPr/newbase/deco','DVAR.mat'),'A_prime')
    VX = VX(:,2);
    A_base = A_prime;
end



pimhat=Dimp_all./Dim;
pifhat=Difp_all./Dif;


for i=1:N*J
    for j=1:N
        if isnan(pimhat(i,j))==1
            pimhat(i,j)=1;
        end
        if isnan(pifhat(i,j))==1
            pifhat(i,j)=1;
        end
    end
end

taum_hat=taump./taum ;
tauf_hat=taufp./tauf ;
 

% tariff rebates
Rp=(PQm_all'*(1-Fmp_all)).*eye(N,N)*ones(N,1)+ (PQf_all'*(1-Ffp_all)).*eye(N,N)*ones(N,1);
R=(Xm0'*(1-Fm)).*eye(N,N)*ones(N,1)+(Xf0'*(1-Ff)).*eye(N,N)*ones(N,1);

Ip=diag(wf0_all)*VAn+Rp-SIn;
I=VAn+R-SIn;

Ap_all=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            Ap_all((i-1)*J+j,(n-1)*J+1:n*J)=pimhat((j-1)*N+n,i)./taum_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end


%Leontief inverse
Bp_all=inv(eye(N*J,N*J)-Ap_all);
B_base=inv(eye(N*J,N*J)-A_base);



%domestic production values (fob - what producers actually get)
Dimp_allf=Dimp_all./taump;
Difp_allf=Difp_all./taufp;

prod_prime=zeros(J,N);

for i=1:N
    for j=1:J
            prod_prime(j,i)= PQm_all(j,:)*Dimp_allf((j-1)*N+1:j*N,i)+PQf_all(j,:)*Difp_allf((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

Dim_f=Dim./taum;
Dif_f=Dif./tauf;

prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod(j,i)= Xm0(j,:)*Dim_f((j-1)*N+1:j*N,i)+Xf0(j,:)*Dif_f((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

% VA embodied in net inventory consumption - baseline

VAI0=zeros(J,N);

for i=1:N
    VAI0(:,i)=diag(B(:,i))* B_base((i-1)*J+1:i*J,(i-1)*J+1:i*J)*Inv(:,i);
end

% VA embodied in net inventory consumption - counterfactual

VAI_prime=zeros(J,N);
for i=1:N
    VAI_prime(:,i)=diag(B(:,i))*Bp_all((i-1)*J+1:i*J,(i-1)*J+1:i*J)*Inv(:,i);
end




% Read out the data

% Counterfactual income
for i=1:N
    Ip(i,2)=i;
end
dlmwrite('cfCHN_Iprime.txt',Ip)



% Initial income
for i=1:N
    I(i,2)=i;
end
dlmwrite('cfCHN_I.txt',I)


% Counterfactual trade change
for j=1:J
    pimhat((j-1)*N+1:j*N,N+1)=j;
    pifhat((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        pimhat((j-1)*N+i,N+2)=i;
        pifhat((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_pimhat.txt',pimhat)
dlmwrite('cfCHN_pifhat.txt',pifhat)


% Counterfactual trade share
for j=1:J
   Dimp_all((j-1)*N+1:j*N,N+1)=j;
   Difp_all((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dimp_all((j-1)*N+i,N+2)=i;
        Difp_all((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_Dimp_all.txt',Dimp_all)
dlmwrite('cfCHN_Difp_all.txt',Difp_all)


% initial trade share
for j=1:J
   Dim((j-1)*N+1:j*N,N+1)=j;
   Dif((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dim((j-1)*N+i,N+2)=i;
        Dif((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_Dim.txt',Dim)
dlmwrite('cfCHN_Dif.txt',Dif)




% Counterfactual leontief matrix

for i=1:N
    for j=1:J
        Bp_all((i-1)*J+j,N*J+1)=j;
    end
end


for i=1:N
   Bp_all((i-1)*J+1:i*J,N*J+2)=i;
end

dlmwrite('cfCHN_B_all.txt',Bp_all);

%initial leontief matrix

for i=1:N
    for j=1:J
        B_base((i-1)*J+j,N*J+1)=j;
    end
end


for i=1:N
   B_base((i-1)*J+1:i*J,N*J+2)=i;
end

dlmwrite('cfCHN_B_base.txt',B_base);




% Counterfactual price change

for j=1:J
    pfm0_all(j,N+1)=j;
    pff0_all(j,N+1)=j;
end
dlmwrite('cfCHN_pfm0_all.txt',pfm0_all);
dlmwrite('cfCHN_pff0_all.txt',pff0_all);


% Counterfactual expenditure level

for j=1:J
    PQm_all(j,N+1)=j;
    PQf_all(j,N+1)=j;
end

dlmwrite('cfCHN_PQm_all.txt',PQm_all);
dlmwrite('cfCHN_PQf_all.txt',PQf_all);


% Initial expenditure level

for j=1:J
    Xm0(j,N+1)=j;
    Xf0(j,N+1)=j;
end

dlmwrite('cfCHN_Xm0.txt',Xm0);
dlmwrite('cfCHN_Xf0.txt',Xf0);



% Counterfactual production

for j=1:J
    prod_prime(j,N+1)=j;
end
dlmwrite('cfCHN_Yprime.txt',prod_prime);



% Initial production

for j=1:J
    prod(j,N+1)=j;
end
dlmwrite('cfCHN_Y.txt',prod);

% Initial VA embodied in net inventory consumption

for j=1:J
    VAI0(j,N+1)=j;
end
dlmwrite('cfCHN_VAI0.txt',VAI0);


% counterfactual VA embodied in net inventory consumption

for j=1:J
    VAI_prime(j,N+1)=j;
end
dlmwrite('cfCHN_VAI_prime.txt',VAI_prime);



% Counterfactual wage changes
for i=1:N
    wf0_all(i,2)=i;
end
dlmwrite('cfCHN_wf0_all.txt',wf0_all)



% counterfactual tariff revenue
for i=1:N
   Rp(i,2)=i;
end
dlmwrite('cfCHN_Rprime.txt',Rp)



% initial tariff revenue
for i=1:N
   R(i,2)=i;
end
dlmwrite('cfCHN_R.txt',R)




% trade deficit
for i=1:N
   Sn(i,2)=i;
end
dlmwrite('cfCHN_S.txt',Sn)




% trade deficit + inventory
for i=1:N
   SIn(i,2)=i;
end
dlmwrite('cfCHN_SI.txt',SIn)



% initial value added
for i=1:N
   VAn(i,2)=i;
end
dlmwrite('cfCHN_VA.txt',VAn)


% inital tariffs

for j=1:J
   taum((j-1)*N+1:j*N,N+1)=j;
   tauf((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taum((j-1)*N+i,N+2)=i;
       tauf((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_taum.txt',taum)
dlmwrite('cfCHN_tauf.txt',tauf)


% counterfactual tariffs

for j=1:J
   taump((j-1)*N+1:j*N,N+1)=j;
   taufp((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taump((j-1)*N+i,N+2)=i;
       taufp((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_taump.txt',taump)
dlmwrite('cfCHN_taufp.txt',taufp)





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VA DECO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load(fn)



t = 2;
s = J;
a = N;


%make new directory for  every "year"

for j=1:t
    k = j-1;
    mkdir(['deco/' int2str(k)])
end


% prep matrices for decompostion
% VA COEFFICIENT
for c=1:t
    r(:,:,c) = B;  % a * s * t
end

%IO-MATRIX
pimhat=Dimp_all./Dim;
pifhat=Difp_all./Dif;

for i=1:N*J
    for j=1:N
        if isnan(pimhat(i,j))==1
            pimhat(i,j)=1;
        end
        if isnan(pifhat(i,j))==1
            pifhat(i,j)=1;
        end
    end
end

taum_hat=taump./taum ;
tauf_hat=taufp./tauf ;
 
A_prime=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            A_prime((i-1)*J+j,(n-1)*J+1:n*J)=pimhat((j-1)*N+n,i)./taum_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end

A = cat(3,A_base,A_prime);


%% TRADE FLOWS
PQm_vec   = reshape(PQm_all',1,J*N)'; 
PQf_vec   = reshape(PQf_all',1,J*N)'; 
Xm0_vec   = reshape(Xm0',1,J*N)'; 
Xf0_vec   = reshape(Xf0',1,J*N)'; 


Dimp_om = Dimp_all./taump;
Difp_om = Difp_all./taufp;
Dim_om = Dim./taum;
Dif_om = Dif./tauf;

for n = 1:1:N
    DPm(:,n)  = Dimp_om(:,n).*PQm_vec; 
    DPf(:,n)  = Difp_om(:,n).*PQf_vec; 
    D0m(:,n)  = Dim_om(:,n).*Xm0_vec; 
    D0f(:,n)  = Dif_om(:,n).*Xf0_vec;
end


% total exports by exporter and sector excluding 'within' China exports

he = eye(a); he(11:14,11:14)=1;

for l=1:1:s
    DPm2((l-1)*a+1:l*a,:) = DPm((l-1)*a+1:l*a,:).*(1-he);
    DPf2((l-1)*a+1:l*a,:) = DPf((l-1)*a+1:l*a,:).*(1-he);
    D0m2((l-1)*a+1:l*a,:) = D0m((l-1)*a+1:l*a,:).*(1-he);
    D0f2((l-1)*a+1:l*a,:) = D0f((l-1)*a+1:l*a,:).*(1-he);
end


for l=1:1:s
    Dmp(l,:) = ones(1,a)*DPm2((l-1)*a+1:l*a,:);
    Dfp(l,:) = ones(1,a)*DPf2((l-1)*a+1:l*a,:);
    Dm(l,:) = ones(1,a)*D0m2((l-1)*a+1:l*a,:);
    Df(l,:) = ones(1,a)*D0f2((l-1)*a+1:l*a,:);
end

 %total exports by exporter and sector

Xp = Dmp+Dfp;
X0 = Dm+Df; 
 
Xp = reshape(Xp,[s*a,1]);
X0 = reshape(X0,[s*a,1]);

xx = cat(3,X0,Xp);





% final goods sales including inventory

inv = zeros(s*a,a);
for n=1:1:N
    inv((n-1)*s+1:n*s,n) = Inv(:,n);
end


%reshape final goods sales from (rows: sector importer, cols: exporter) to
% rows: exporter sector, cols importer

for n=1:1:a
        for j=1:1:s
            rDPf((n-1)*s+j,:) = DPf((j-1)*a+1:j*a,n)';
            rD0f((n-1)*s+j,:) = D0f((j-1)*a+1:j*a,n)';
            rD0f2((n-1)*s+j,:) = D0f2((j-1)*a+1:j*a,n)';
            rDPf2((n-1)*s+j,:) = DPf2((j-1)*a+1:j*a,n)';
        end
end



Cfp = rDPf + inv;
Cf = rD0f + inv;

C = cat(3,Cf,Cfp);


% final goods exports excluding intra CHN

Cc = cat(3,rD0f2,rDPf2);

%% OUTPUT
prod_prime=zeros(J,N);
prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod_prime(j,i)= PQm_all(j,:)*Dimp_om((j-1)*N+1:j*N,i)+PQf_all(j,:)*Difp_om((j-1)*N+1:j*N,i)+Inv(j,i);
            prod(j,i)= Xm0(j,:)*Dim_om((j-1)*N+1:j*N,i)+Xf0(j,:)*Dif_om((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

op = reshape(prod_prime,[s*a,1]);
o0 = reshape(prod,[s*a,1]);
o = cat(3,o0,op);


clearvars -except o C Cc A r s a t xx J N A_prime VX e fn parent home


% %%%%%%%%%%%%%%%%%%%%%%%%%%             HELP MATRICES



% World Leontief scaled by va coefficient
% Leontief inverse of world input-output table for each year
B=zeros(s*a,s*a,t);

for j=1:t
  B(:,:,j) = inv(eye(a*s)-A(:,:,j));
end

vlong = reshape(r,[a*s,1,t]);

for j=1:t
    VB(:,:,j) = transpose( diag(vlong(:,:,j))*B(:,:,j) );
end

%%%%% total final goods output (exports plus domestic sales and inventory)
for j=1:t
    Y(:,:,j) = C(:,:,j)*ones(a,1);
end



% sum over importers to
% reshape final demand from
%       first dimension: sourcing country-sector
%       second dimension: demanding country
%       third dim: year

%to 
%       first dimension: sourcing country-sector
%       second dimension: year


y = zeros(a*s,1,t);

for j=1:t
    y(:,:,j) = Cc(:,:,j)*ones(a,1);
end



% matrix with total final goods export vectors on "diagonal"
for j=1:t
    for i=1:a
        ydiag((i-1)*s+1:i*s,i,j) = y((i-1)*s+1:i*s,1,j);
    end
end




%domestic leontiefs on diagonal submatrics

L = zeros(a*s,a*s,t);

for j=1:t
    for i=1:a
        L( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j )  =   inv( eye(s) - A( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j ) );
    end
end


%% !!!! replace intra-CHN Leontief
for j=1:t
    L( 10*s+1:14*s,10*s+1:14*s,j) = inv(eye(4*s)-A(10*s+1:14*s,10*s+1:14*s,j));
end


% VB-type matrix based on domestic leontiefs only

for j=1:t
    VL(:,:,j) = transpose( diag(vlong(:,:,j))*L(:,:,j) );
end





% B-matrix without diagonals and without intra-China

Ih = eye(a); Ih(11:14,11:14) = 1;

for j=1:t
    Bz(:,:,j) = ones(a*s,a*s)-kron(Ih,ones(s));
end

Bz=Bz.*B;



% B with diagonal blocks only

Bd = B-Bz;


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end



%premultiply total exports xx by domestic leontief

Lye=zeros(s*a,1,t);
for j=1:t
    Lye(:,:,j) = L(:,:,j)*xx(:,:,j);
end




% VB-type matrix based on B zero

for j=1:t
    VBz(:,:,j) = transpose( diag(vlong(:,:,j))*Bz(:,:,j) );
end


% domestic final demand (including inventory)



I = eye(a);
I(11:14,11:14)=1;
Azc = kron(I,ones(s,1));  % the within China connections

cD = C.*Azc; % set-off diagonal and non-intra-CHN flows to zero

yd = zeros(a*s,1,t);


for j=1:t
    yd(:,:,j) = cD(:,:,j)*ones(a,1);
end




%premultiply total domestic final good absorption by domestic leontief

Lyd=zeros(s*a,1,t);
for j=1:t
    Lyd(:,:,j) = L(:,:,j)*yd(:,:,j);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  domestic and foreign va content of total exports %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%% country-sector va content -- TRANSPOSED structure of io tab
% columns: source sectors wi countries
% rows: demanding sectors wi countries (EXPORTERS)
%--> will be transposed below

VAFE = VB.*y; %domestic and foreign value added content of final goods exports




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% domestic value added content of intermediate goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% sum of terms 2 - 9 
%%%%%%%%%%%%%%%%%%%% double-counted term 9 will be substracted below


%%%%% total final goods output (exports plus domestic sales and inventory)


% A-matrix without diagonals and intra-China

for j=1:t
    Az(:,:,j) = ones(a*s,a*s)-kron(I,ones(s));
end

Az=Az.*A;

for j=1:t
 AzBY(:,:,j) = Az(:,:,j)*B(:,:,j)*Y(:,:,j);
end


VAIE9=VL.*AzBY; % domestic value added content of intermediate goods exports including returned domestic va and - at this stage, returned and reexported  va which is substracted below


%returned domestic va (terms 6-8)
for j=1:t
    BC(:,:,j)=B(:,:,j)*C(:,:,j);
end

for j=1:t
    for n = 1:a
        AzBYret((n-1)*s+1:n*s,1,j) = Az((n-1)*s+1:n*s,:,j)*BC(:,n,j);
    end
end



RDV = VL.*AzBYret; % returned domestic va
% note that this is terms 6-8




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% prep DOUBLE-COUNTED VA

%% TERMS 9 & 10: double counted domestic va



% Term 9



for j=1:t
    ABzy(:,:,j) = Az(:,:,j)*Bz(:,:,j)*ydiag(:,:,j);   
end



%set non-diagonal vectors = zero and write in column vector

ABzys = zeros(a*s,1,t);
for j=1:t
    for i=1:a
        ABzys( (i-1)*s+1:i*s,1,j) = ABzy((i-1)*s+1:i*s,i,j);
    end
end


DCDVAE9 = VL.*ABzys;   % double-counted domestic value added caused by final goods exports

VAIE=VAIE9-DCDVAE9;  %domestic va in intermediate exports net of double counting




% term 10:

for j=1:t
    Azo(:,:,j) =Az(:,:,j)*o(:,:,j);
end


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end

DCDVAE10 = (VBd-VL).*Azo;

DCDVAE=DCDVAE9+DCDVAE10;
clear DCDVAE9 DCDVAE10





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% double-counted foreign value added content of exports %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% TERMS 13 & 16: double counted foreign va


%sum over final countries
Azye=zeros(s*a,1,t);
for j=1:t
    Azye(:,1,j)=Az(:,:,j)*Lye(:,:,j);
end

DCFVAE = VBz.*Azye;  % double-counted foreign value added





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% foreign value added %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% terms 12 and 15 (structure identical to 13 & 16)

%sum over final countries
Azyd=zeros(s*a,1,t);
for j=1:t
    Azyd(:,1,j)=Az(:,:,j)*Lyd(:,:,j);
end


FVAE = VBz.*Azyd;  % double-counted foreign value added






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% transpose - source in rows, exporters in columns -> same element
% interpretation as in world input-output table


for j=1:1:t
    VAFE(:,:,j)=VAFE(:,:,j)';
    VAIE(:,:,j)=VAIE(:,:,j)';
    FVAE(:,:,j)=FVAE(:,:,j)';
    DCDVAE(:,:,j)=DCDVAE(:,:,j)';
    DCFVAE(:,:,j)=DCFVAE(:,:,j)';  
    RDV(:,:,j)=RDV(:,:,j)';  
end

%total value added in exports:
TVAE = VAFE + VAIE + FVAE  + DCDVAE + DCFVAE ;
% RDV is included in VAIE

%% tests
% with positive tariffs and original betas, the residual should be positive
% with trial betas (see top), residual should be zero
%summing over VA sources for a given sector's exports
for j=1:t
    ext(:,:,j)=sum(TVAE(:,:,j));
end

ext1=ext(:,:,1);
xx1=xx(:,:,1)';
te=xx1-ext1;


DV = VAFE + VAIE + FVAE;
DVDC = VAFE + VAIE + DCDVAE +  DCFVAE + FVAE;

%clear VAFE VAIE DCDVAE FVAE DCFVAE

Az = kron(eye(a),ones(s,s));
Az(10*s+1:14*s,10*s+1:14*s)=1;  % the within China connections

DV = Az.*DV; %set source! = exporter -> zero
DVDC = Az.*DVDC;

DV = sum(DV,1); % sum over source sectors
DVDC = sum(DVDC,1); % sum over source sectors

clearvars -except DV DVDC VAFE VAIE DCDVAE DCFVAE FVAE RDV xx t s a C VB J N A_prime VX e fn parent home


xx=squeeze(xx);
DV=squeeze(DV);
DVDC=squeeze(DVDC);




%%%%%%%%%%%%%%%%%%%%%%%% VAX RATIO %%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%



% individual export destinations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% destination-specific domestic and foreign va content %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


tt = 2;

if (e == 1)
    tt = 1;
end

for j=tt:t %do this only for counterfactual and load baseline from previous files
    k = -1+j;
    

VAFE_bh=[]; 

 

for h = 1:a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports to x %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14

y_h = [zeros((h-1),1); 1 ; zeros((a-h),1) ];

%final goods export to destination x

    y_b(:,:) = C(:,:,j)*y_h;

%y_h = [zeros((11-1)*s,1); ones(s,1) ; zeros((a-11)*s,1) ];

VAFE_b = VB(:,:,j).*y_b; %domestic and foreign value added content of final goods exports

VAFE_b=VAFE_b';


VAFE_bh = cat(3,VAFE_bh,VAFE_b);


end


 f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');
if (e == 1)
    save(f, 'VAFE_bh', '-v7.3')
end
end

clear C VB y_h y_b VAFE_b

if (e>1)
    VX = VX(:,1); %imported baseline
    tt=2;
end

if (e == 1)
    VX=[];
    tt = 1;
end

for j=tt:t
    k = -1+j;
 
if (e == 1)
    f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');
    load(f,'VAFE_bh')
end

vafe = squeeze(sum(VAFE_bh,2)); %squeeze removes singleton dimension

I = eye(a); I(11:14,11:14)=1; %set countries fg exports to themselves =0 and set all Chinas' fg exports to the other Chinas = 0

he = 1-kron(I,ones(s,1));

VAX = vafe.*he*ones(a,1);

VX = [VX VAX];

end


save deco/DVAR


DV0=squeeze(DV(:,1));
VX0=squeeze(VX(:,1));


DVp=squeeze(DV(:,2));
VXp=squeeze(VX(:,2));

for i=1:N
    for j=1:J
        DV0((i-1)*J+j,2)=j;
        VX0((i-1)*J+j,2)=j;
        DVp((i-1)*J+j,2)=j;
        VXp((i-1)*J+j,2)=j;
    end
end

for i=1:N
   DV0((i-1)*J+1:i*J,3)=i;
   VX0((i-1)*J+1:i*J,3)=i;
   DVp((i-1)*J+1:i*J,3)=i;
   VXp((i-1)*J+1:i*J,3)=i;
end

dlmwrite('deco/cfCHN_DV0.txt',DV0)
dlmwrite('deco/cfCHN_VAX0.txt',VX0)

dlmwrite('deco/cfCHN_DVp.txt',DVp)
dlmwrite('deco/cfCHN_VAXp.txt',VXp)





%%%% write out va changes for baseline


if (e==1)
    
load(fn)
load deco/DVAR


VAFE_t=[];VAIE_t=[];DCDVAE_t=[];DCFVAE_t=[];FVAE_t=[];RDV_t=[];

for j=1:1:t
    VAFE_t=[VAFE_t; VAFE(:,:,j)];
    VAIE_t=[VAIE_t; VAIE(:,:,j)];
    DCDVAE_t=[DCDVAE_t; DCDVAE(:,:,j)];
    DCFVAE_t=[DCFVAE_t; DCFVAE(:,:,j)];
    FVAE_t=[FVAE_t; FVAE(:,:,j)];
    RDV_t=[RDV_t; RDV(:,:,j)];

end

dlmwrite('deco/VAFE.txt',VAFE_t);
dlmwrite('deco/VAIE.txt',VAIE_t);
dlmwrite('deco/FVAE.txt',FVAE_t);
dlmwrite('deco/DCDVAE.txt',DCDVAE_t);
dlmwrite('deco/DCFVAE.txt',DCFVAE_t);
dlmwrite('deco/RDV.txt',RDV_t);

end

end







%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Results for the scenarios where the trade deficit changes %%%%%%%%%%%%%%%%%%
%% Table 5 rows h, i





for e= 102:103; 

run(fullfile(parent,'scenariolist'))
fn = fullfile(home,folder,file);
cd(fileparts(fn))

load(fn)

A_base=importdata(fullfile(parent,'Baseline','ioc2000.txt'));


SInp=SIn;
Snp = Sn;
VPp = VP;
Invp = Inv;

clear SIn Sn VP Inc

load(fullfile(home,'WTOCHN2007OC','WTOCHN2007OC.mat'),'SIn','Sn','VP','Inv')
load(fullfile(home,'WTOCHN2007OC/deco','DVAR.mat'),'VX') 




pimhat=Dimp_all./Dim;
pifhat=Difp_all./Dif;


for i=1:N*J
    for j=1:N
        if isnan(pimhat(i,j))==1
            pimhat(i,j)=1;
        end
        if isnan(pifhat(i,j))==1
            pifhat(i,j)=1;
        end
    end
end

taum_hat=taump./taum ;
tauf_hat=taufp./tauf ;
 

% tariff rebates
Rp=(PQm_all'*(1-Fmp_all)).*eye(N,N)*ones(N,1)+ (PQf_all'*(1-Ffp_all)).*eye(N,N)*ones(N,1);
R=(Xm0'*(1-Fm)).*eye(N,N)*ones(N,1)+(Xf0'*(1-Ff)).*eye(N,N)*ones(N,1);

Ip=diag(wf0_all)*VAn+Rp-SInp;
I=VAn+R-SIn;

Ap_all=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            Ap_all((i-1)*J+j,(n-1)*J+1:n*J)=pimhat((j-1)*N+n,i)./taum_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end


%Leontief inverse
Bp_all=inv(eye(N*J,N*J)-Ap_all);
B_base=inv(eye(N*J,N*J)-A_base);



%domestic production values (fob - what producers actually get)
Dimp_allf=Dimp_all./taump;
Difp_allf=Difp_all./taufp;

prod_prime=zeros(J,N);

for i=1:N
    for j=1:J
            prod_prime(j,i)= PQm_all(j,:)*Dimp_allf((j-1)*N+1:j*N,i)+PQf_all(j,:)*Difp_allf((j-1)*N+1:j*N,i)+Invp(j,i);
    end
end

Dim_f=Dim./taum;
Dif_f=Dif./tauf;

prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod(j,i)= Xm0(j,:)*Dim_f((j-1)*N+1:j*N,i)+Xf0(j,:)*Dif_f((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

% VA embodied in net inventory consumption - baseline

VAI0=zeros(J,N);

for i=1:N
    VAI0(:,i)=diag(B(:,i))* B_base((i-1)*J+1:i*J,(i-1)*J+1:i*J)*Inv(:,i);
end

% VA embodied in net inventory consumption - counterfactual

VAI_prime=zeros(J,N);
for i=1:N
    VAI_prime(:,i)=diag(B(:,i))*Bp_all((i-1)*J+1:i*J,(i-1)*J+1:i*J)*Invp(:,i);
end




% Read out the data

% Counterfactual income
for i=1:N
    Ip(i,2)=i;
end
dlmwrite('cfCHN_Iprime.txt',Ip)



% Initial income
for i=1:N
    I(i,2)=i;
end
dlmwrite('cfCHN_I.txt',I)


% Counterfactual trade change
for j=1:J
    pimhat((j-1)*N+1:j*N,N+1)=j;
    pifhat((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        pimhat((j-1)*N+i,N+2)=i;
        pifhat((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_pimhat.txt',pimhat)
dlmwrite('cfCHN_pifhat.txt',pifhat)


% Counterfactual trade share
for j=1:J
   Dimp_all((j-1)*N+1:j*N,N+1)=j;
   Difp_all((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dimp_all((j-1)*N+i,N+2)=i;
        Difp_all((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_Dimp_all.txt',Dimp_all)
dlmwrite('cfCHN_Difp_all.txt',Difp_all)


% initial trade share
for j=1:J
   Dim((j-1)*N+1:j*N,N+1)=j;
   Dif((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dim((j-1)*N+i,N+2)=i;
        Dif((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_Dim.txt',Dim)
dlmwrite('cfCHN_Dif.txt',Dif)




% Counterfactual leontief matrix

for i=1:N
    for j=1:J
        Bp_all((i-1)*J+j,N*J+1)=j;
    end
end


for i=1:N
   Bp_all((i-1)*J+1:i*J,N*J+2)=i;
end

dlmwrite('cfCHN_B_all.txt',Bp_all);

%initial leontief matrix

for i=1:N
    for j=1:J
        B_base((i-1)*J+j,N*J+1)=j;
    end
end


for i=1:N
   B_base((i-1)*J+1:i*J,N*J+2)=i;
end

dlmwrite('cfCHN_B_base.txt',B_base);




% Counterfactual price change

for j=1:J
    pfm0_all(j,N+1)=j;
    pff0_all(j,N+1)=j;
end
dlmwrite('cfCHN_pfm0_all.txt',pfm0_all);
dlmwrite('cfCHN_pff0_all.txt',pff0_all);


% Counterfactual expenditure level

for j=1:J
    PQm_all(j,N+1)=j;
    PQf_all(j,N+1)=j;
end

dlmwrite('cfCHN_PQm_all.txt',PQm_all);
dlmwrite('cfCHN_PQf_all.txt',PQf_all);


% Initial expenditure level

for j=1:J
    Xm0(j,N+1)=j;
    Xf0(j,N+1)=j;
end

dlmwrite('cfCHN_Xm0.txt',Xm0);
dlmwrite('cfCHN_Xf0.txt',Xf0);



% Counterfactual production

for j=1:J
    prod_prime(j,N+1)=j;
end
dlmwrite('cfCHN_Yprime.txt',prod_prime);



% Initial production

for j=1:J
    prod(j,N+1)=j;
end
dlmwrite('cfCHN_Y.txt',prod);

% Initial VA embodied in net inventory consumption

for j=1:J
    VAI0(j,N+1)=j;
end
dlmwrite('cfCHN_VAI0.txt',VAI0);


% counterfactual VA embodied in net inventory consumption

for j=1:J
    VAI_prime(j,N+1)=j;
end
dlmwrite('cfCHN_VAI_prime.txt',VAI_prime);



% Counterfactual wage changes
for i=1:N
    wf0_all(i,2)=i;
end
dlmwrite('cfCHN_wf0_all.txt',wf0_all)



% counterfactual tariff revenue
for i=1:N
   Rp(i,2)=i;
end
dlmwrite('cfCHN_Rprime.txt',Rp)



% initial tariff revenue
for i=1:N
   R(i,2)=i;
end
dlmwrite('cfCHN_R.txt',R)




% trade deficit
for i=1:N
   Sn(i,2)=i;
end
dlmwrite('cfCHN_S.txt',Sn)




% trade deficit + inventory
for i=1:N
   SIn(i,2)=i;
end
dlmwrite('cfCHN_SI.txt',SIn)



% initial value added
for i=1:N
   VAn(i,2)=i;
end
dlmwrite('cfCHN_VA.txt',VAn)


% inital tariffs

for j=1:J
   taum((j-1)*N+1:j*N,N+1)=j;
   tauf((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taum((j-1)*N+i,N+2)=i;
       tauf((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_taum.txt',taum)
dlmwrite('cfCHN_tauf.txt',tauf)


% counterfactual tariffs

for j=1:J
   taump((j-1)*N+1:j*N,N+1)=j;
   taufp((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taump((j-1)*N+i,N+2)=i;
       taufp((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_taump.txt',taump)
dlmwrite('cfCHN_taufp.txt',taufp)




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VA DECO

load(fn)


t = 2;
s = J;
a = N;


%make new directory for  every "year"

for j=1:t
    k = j-1;
    mkdir(['deco/' int2str(k)])
end


% prep matrices for decompostion
% VA COEFFICIENT
for c=1:t
    r(:,:,c) = B;  % a * s * t
end

%IO-MATRIX
pimhat=Dimp_all./Dim;
pifhat=Difp_all./Dif;

for i=1:N*J
    for j=1:N
        if isnan(pimhat(i,j))==1
            pimhat(i,j)=1;
        end
        if isnan(pifhat(i,j))==1
            pifhat(i,j)=1;
        end
    end
end

taum_hat=taump./taum ;
tauf_hat=taufp./tauf ;
 
A_prime=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            A_prime((i-1)*J+j,(n-1)*J+1:n*J)=pimhat((j-1)*N+n,i)./taum_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end

A = cat(3,A_base,A_prime);


%% TRADE FLOWS
PQm_vec   = reshape(PQm_all',1,J*N)'; 
PQf_vec   = reshape(PQf_all',1,J*N)'; 
Xm0_vec   = reshape(Xm0',1,J*N)'; 
Xf0_vec   = reshape(Xf0',1,J*N)'; 


Dimp_om = Dimp_all./taump;
Difp_om = Difp_all./taufp;
Dim_om = Dim./taum;
Dif_om = Dif./tauf;

for n = 1:1:N
    DPm(:,n)  = Dimp_om(:,n).*PQm_vec; 
    DPf(:,n)  = Difp_om(:,n).*PQf_vec; 
    D0m(:,n)  = Dim_om(:,n).*Xm0_vec; 
    D0f(:,n)  = Dif_om(:,n).*Xf0_vec;
end


% total exports by exporter and sector excluding 'within' China exports

he = eye(a); he(11:14,11:14)=1;

for l=1:1:s
    DPm2((l-1)*a+1:l*a,:) = DPm((l-1)*a+1:l*a,:).*(1-he);
    DPf2((l-1)*a+1:l*a,:) = DPf((l-1)*a+1:l*a,:).*(1-he);
    D0m2((l-1)*a+1:l*a,:) = D0m((l-1)*a+1:l*a,:).*(1-he);
    D0f2((l-1)*a+1:l*a,:) = D0f((l-1)*a+1:l*a,:).*(1-he);
end


for l=1:1:s
    Dmp(l,:) = ones(1,a)*DPm2((l-1)*a+1:l*a,:);
    Dfp(l,:) = ones(1,a)*DPf2((l-1)*a+1:l*a,:);
    Dm(l,:) = ones(1,a)*D0m2((l-1)*a+1:l*a,:);
    Df(l,:) = ones(1,a)*D0f2((l-1)*a+1:l*a,:);
end

 %total exports by exporter and sector

Xp = Dmp+Dfp;
X0 = Dm+Df; 
 
Xp = reshape(Xp,[s*a,1]);
X0 = reshape(X0,[s*a,1]);

xx = cat(3,X0,Xp);





% final goods sales including inventory

inv = zeros(s*a,a);
invp = zeros(s*a,a);

for n=1:1:N
    inv((n-1)*s+1:n*s,n) = Inv(:,n);
    invp((n-1)*s+1:n*s,n) = Invp(:,n);
end


%reshape final goods sales from (rows: sector importer, cols: exporter) to
% rows: exporter sector, cols importer

for n=1:1:a
        for j=1:1:s
            rDPf((n-1)*s+j,:) = DPf((j-1)*a+1:j*a,n)';
            rD0f((n-1)*s+j,:) = D0f((j-1)*a+1:j*a,n)';
            rD0f2((n-1)*s+j,:) = D0f2((j-1)*a+1:j*a,n)';
            rDPf2((n-1)*s+j,:) = DPf2((j-1)*a+1:j*a,n)';
        end
end



Cfp = rDPf + invp;
Cf = rD0f + inv;

C = cat(3,Cf,Cfp);


% final goods exports excluding intra CHN

Cc = cat(3,rD0f2,rDPf2);

%% OUTPUT
prod_prime=zeros(J,N);
prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod_prime(j,i)= PQm_all(j,:)*Dimp_om((j-1)*N+1:j*N,i)+PQf_all(j,:)*Difp_om((j-1)*N+1:j*N,i)+Invp(j,i);
            prod(j,i)= Xm0(j,:)*Dim_om((j-1)*N+1:j*N,i)+Xf0(j,:)*Dif_om((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

op = reshape(prod_prime,[s*a,1]);
o0 = reshape(prod,[s*a,1]);
o = cat(3,o0,op);


clearvars -except o C Cc A r s a t xx J N A_prime VX e fn parent home


% %%%%%%%%%%%%%%%%%%%%%%%%%%             HELP MATRICES



% World Leontief scaled by va coefficient
% Leontief inverse of world input-output table for each year
B=zeros(s*a,s*a,t);

for j=1:t
  B(:,:,j) = inv(eye(a*s)-A(:,:,j));
end

vlong = reshape(r,[a*s,1,t]);

for j=1:t
    VB(:,:,j) = transpose( diag(vlong(:,:,j))*B(:,:,j) );
end

%%%%% total final goods output (exports plus domestic sales and inventory)
for j=1:t
    Y(:,:,j) = C(:,:,j)*ones(a,1);
end



% sum over importers to
% reshape final demand from
%       first dimension: sourcing country-sector
%       second dimension: demanding country
%       third dim: year

%to 
%       first dimension: sourcing country-sector
%       second dimension: year


y = zeros(a*s,1,t);

for j=1:t
    y(:,:,j) = Cc(:,:,j)*ones(a,1);
end



% matrix with total final goods export vectors on "diagonal"
for j=1:t
    for i=1:a
        ydiag((i-1)*s+1:i*s,i,j) = y((i-1)*s+1:i*s,1,j);
    end
end




%domestic leontiefs on diagonal submatrics

L = zeros(a*s,a*s,t);

for j=1:t
    for i=1:a
        L( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j )  =   inv( eye(s) - A( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j ) );
    end
end


%% !!!! replace intra-CHN Leontief
for j=1:t
    L( 10*s+1:14*s,10*s+1:14*s,j) = inv(eye(4*s)-A(10*s+1:14*s,10*s+1:14*s,j));
end


% VB-type matrix based on domestic leontiefs only

for j=1:t
    VL(:,:,j) = transpose( diag(vlong(:,:,j))*L(:,:,j) );
end





% B-matrix without diagonals and without intra-China

Ih = eye(a); Ih(11:14,11:14) = 1;

for j=1:t
    Bz(:,:,j) = ones(a*s,a*s)-kron(Ih,ones(s));
end

Bz=Bz.*B;



% B with diagonal blocks only

Bd = B-Bz;


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end



%premultiply total exports xx by domestic leontief

Lye=zeros(s*a,1,t);
for j=1:t
    Lye(:,:,j) = L(:,:,j)*xx(:,:,j);
end




% VB-type matrix based on B zero

for j=1:t
    VBz(:,:,j) = transpose( diag(vlong(:,:,j))*Bz(:,:,j) );
end


% domestic final demand (including inventory)



I = eye(a);
I(11:14,11:14)=1;
Azc = kron(I,ones(s,1));  % the within China connections

cD = C.*Azc; % set-off diagonal and non-intra-CHN flows to zero

yd = zeros(a*s,1,t);


for j=1:t
    yd(:,:,j) = cD(:,:,j)*ones(a,1);
end




%premultiply total domestic final good absorption by domestic leontief

Lyd=zeros(s*a,1,t);
for j=1:t
    Lyd(:,:,j) = L(:,:,j)*yd(:,:,j);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  domestic and foreign va content of total exports %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%% country-sector va content -- TRANSPOSED structure of io tab
% columns: source sectors wi countries
% rows: demanding sectors wi countries (EXPORTERS)
%--> will be transposed below

VAFE = VB.*y; %domestic and foreign value added content of final goods exports




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% domestic value added content of intermediate goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% sum of terms 2 - 9 
%%%%%%%%%%%%%%%%%%%% double-counted term 9 will be substracted below


%%%%% total final goods output (exports plus domestic sales and inventory)


% A-matrix without diagonals and intra-China

for j=1:t
    Az(:,:,j) = ones(a*s,a*s)-kron(I,ones(s));
end

Az=Az.*A;

for j=1:t
 AzBY(:,:,j) = Az(:,:,j)*B(:,:,j)*Y(:,:,j);
end


VAIE9=VL.*AzBY; % domestic value added content of intermediate goods exports including returned domestic va and - at this stage, returned and reexported  va which is substracted below


%returned domestic va (terms 6-8)
for j=1:t
    BC(:,:,j)=B(:,:,j)*C(:,:,j);
end

for j=1:t
    for n = 1:a
        AzBYret((n-1)*s+1:n*s,1,j) = Az((n-1)*s+1:n*s,:,j)*BC(:,n,j);
    end
end



RDV = VL.*AzBYret; % returned domestic va
% note that this is terms 6-8




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% prep DOUBLE-COUNTED VA

%% TERMS 9 & 10: double counted domestic va



% Term 9



for j=1:t
    ABzy(:,:,j) = Az(:,:,j)*Bz(:,:,j)*ydiag(:,:,j);   
end



%set non-diagonal vectors = zero and write in column vector

ABzys = zeros(a*s,1,t);
for j=1:t
    for i=1:a
        ABzys( (i-1)*s+1:i*s,1,j) = ABzy((i-1)*s+1:i*s,i,j);
    end
end


DCDVAE9 = VL.*ABzys;   % double-counted domestic value added caused by final goods exports

VAIE=VAIE9-DCDVAE9;  %domestic va in intermediate exports net of double counting




% term 10:

for j=1:t
    Azo(:,:,j) =Az(:,:,j)*o(:,:,j);
end


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end

DCDVAE10 = (VBd-VL).*Azo;

DCDVAE=DCDVAE9+DCDVAE10;
clear DCDVAE9 DCDVAE10





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% double-counted foreign value added content of exports %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% TERMS 13 & 16: double counted foreign va


%sum over final countries
Azye=zeros(s*a,1,t);
for j=1:t
    Azye(:,1,j)=Az(:,:,j)*Lye(:,:,j);
end

DCFVAE = VBz.*Azye;  % double-counted foreign value added





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% foreign value added %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% terms 12 and 15 (structure identical to 13 & 16)

%sum over final countries
Azyd=zeros(s*a,1,t);
for j=1:t
    Azyd(:,1,j)=Az(:,:,j)*Lyd(:,:,j);
end


FVAE = VBz.*Azyd;  % double-counted foreign value added






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% transpose - source in rows, exporters in columns -> same element
% interpretation as in world input-output table


for j=1:1:t
    VAFE(:,:,j)=VAFE(:,:,j)';
    VAIE(:,:,j)=VAIE(:,:,j)';
    FVAE(:,:,j)=FVAE(:,:,j)';
    DCDVAE(:,:,j)=DCDVAE(:,:,j)';
    DCFVAE(:,:,j)=DCFVAE(:,:,j)';  
    RDV(:,:,j)=RDV(:,:,j)';  
end

%total value added in exports:
TVAE = VAFE + VAIE + FVAE  + DCDVAE + DCFVAE ;
% RDV is included in VAIE

%% tests
% with positive tariffs and original betas, the residual should be positive
% with trial betas (see top), residual should be zero
%summing over VA sources for a given sector's exports
for j=1:t
    ext(:,:,j)=sum(TVAE(:,:,j));
end

ext1=ext(:,:,1);
xx1=xx(:,:,1)';
te=xx1-ext1;


DV = VAFE + VAIE + FVAE;
DVDC = VAFE + VAIE + DCDVAE +  DCFVAE + FVAE;

%clear VAFE VAIE DCDVAE FVAE DCFVAE

Az = kron(eye(a),ones(s,s));
Az(10*s+1:14*s,10*s+1:14*s)=1;  % the within China connections

DV = Az.*DV; %set source! = exporter -> zero
DVDC = Az.*DVDC;

DV = sum(DV,1); % sum over source sectors
DVDC = sum(DVDC,1); % sum over source sectors

clearvars -except DV DVDC VAFE VAIE DCDVAE DCFVAE FVAE RDV xx t s a C VB J N A_prime VX e fn parent home


xx=squeeze(xx);
DV=squeeze(DV);
DVDC=squeeze(DVDC);




%%%%%%%%%%%%%%%%%%%%%%%% VAX RATIO %%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%



% individual export destinations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% destination-specific domestic and foreign va content %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


tt = 2;

if (e == 1)
    tt = 1;
end

for j=tt:t %do this only for counterfactual and load baseline from previous files
    k = -1+j;
    

VAFE_bh=[]; 

 

for h = 1:a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports to x %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14

y_h = [zeros((h-1),1); 1 ; zeros((a-h),1) ];

%final goods export to destination x

    y_b(:,:) = C(:,:,j)*y_h;

%y_h = [zeros((11-1)*s,1); ones(s,1) ; zeros((a-11)*s,1) ];

VAFE_b = VB(:,:,j).*y_b; %domestic and foreign value added content of final goods exports

VAFE_b=VAFE_b';


VAFE_bh = cat(3,VAFE_bh,VAFE_b);


end


 f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');

 save(f, 'VAFE_bh', '-v7.3')

end

clear C VB y_h y_b VAFE_b

    VX = VX(:,1); %imported baseline
    tt=2;


if (e == 1)
    VX=[];
    tt = 1;
end

for j=tt:t
    k = -1+j;
 
if (e == 1)
    f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');
    load(f,'VAFE_bh')
end

vafe = squeeze(sum(VAFE_bh,2)); %squeeze removes singleton dimension

I = eye(a); I(11:14,11:14)=1; %set countries fg exports to themselves =0 and set all Chinas' fg exports to the other Chinas = 0

he = 1-kron(I,ones(s,1));

VAX = vafe.*he*ones(a,1);

VX = [VX VAX];

end



save deco/DVAR


DV0=squeeze(DV(:,1));
VX0=squeeze(VX(:,1));


DVp=squeeze(DV(:,2));
VXp=squeeze(VX(:,2));

for i=1:N
    for j=1:J
        DV0((i-1)*J+j,2)=j;
        VX0((i-1)*J+j,2)=j;
        DVp((i-1)*J+j,2)=j;
        VXp((i-1)*J+j,2)=j;
    end
end

for i=1:N
   DV0((i-1)*J+1:i*J,3)=i;
   VX0((i-1)*J+1:i*J,3)=i;
   DVp((i-1)*J+1:i*J,3)=i;
   VXp((i-1)*J+1:i*J,3)=i;
end

dlmwrite('deco/cfCHN_DV0.txt',DV0)
dlmwrite('deco/cfCHN_VAX0.txt',VX0)

dlmwrite('deco/cfCHN_DVp.txt',DVp)
dlmwrite('deco/cfCHN_VAXp.txt',VXp)


end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% results for scenario TABLE 4 row i


for e= 101:101 

run(fullfile(parent,'scenariolist'))
fn = fullfile(home,folder,file);
cd(fileparts(fn))

load(fn)

A_base=importdata(fullfile(parent,'OOC','ioc2000.txt'));


pimhat=Dimp_all./Dim;
pifhat=Difp_all./Dif;


for i=1:N*J
    for j=1:N
        if isnan(pimhat(i,j))==1
            pimhat(i,j)=1;
        end
        if isnan(pifhat(i,j))==1
            pifhat(i,j)=1;
        end
    end
end

taum_hat=taump./taum ;
tauf_hat=taufp./tauf ;
 

% tariff rebates
Rp=(PQm_all'*(1-Fmp_all)).*eye(N,N)*ones(N,1)+ (PQf_all'*(1-Ffp_all)).*eye(N,N)*ones(N,1);
R=(Xm0'*(1-Fm)).*eye(N,N)*ones(N,1)+(Xf0'*(1-Ff)).*eye(N,N)*ones(N,1);

Ip=diag(wf0_all)*VAn+Rp-SIn;
I=VAn+R-SIn;

Ap_all=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            Ap_all((i-1)*J+j,(n-1)*J+1:n*J)=pimhat((j-1)*N+n,i)./taum_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end


%Leontief inverse
Bp_all=inv(eye(N*J,N*J)-Ap_all);
B_base=inv(eye(N*J,N*J)-A_base);



%domestic production values (fob - what producers actually get)
Dimp_allf=Dimp_all./taump;
Difp_allf=Difp_all./taufp;

prod_prime=zeros(J,N);

for i=1:N
    for j=1:J
            prod_prime(j,i)= PQm_all(j,:)*Dimp_allf((j-1)*N+1:j*N,i)+PQf_all(j,:)*Difp_allf((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

Dim_f=Dim./taum;
Dif_f=Dif./tauf;

prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod(j,i)= Xm0(j,:)*Dim_f((j-1)*N+1:j*N,i)+Xf0(j,:)*Dif_f((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

% VA embodied in net inventory consumption - baseline

VAI0=zeros(J,N);

for i=1:N
    VAI0(:,i)=diag(B(:,i))* B_base((i-1)*J+1:i*J,(i-1)*J+1:i*J)*Inv(:,i);
end

% VA embodied in net inventory consumption - counterfactual

VAI_prime=zeros(J,N);
for i=1:N
    VAI_prime(:,i)=diag(B(:,i))*Bp_all((i-1)*J+1:i*J,(i-1)*J+1:i*J)*Inv(:,i);
end




% Read out the data

% Counterfactual income
for i=1:N
    Ip(i,2)=i;
end
dlmwrite('cfCHN_Iprime.txt',Ip)



% Initial income
for i=1:N
    I(i,2)=i;
end
dlmwrite('cfCHN_I.txt',I)


% Counterfactual trade change
for j=1:J
    pimhat((j-1)*N+1:j*N,N+1)=j;
    pifhat((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        pimhat((j-1)*N+i,N+2)=i;
        pifhat((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_pimhat.txt',pimhat)
dlmwrite('cfCHN_pifhat.txt',pifhat)


% Counterfactual trade share
for j=1:J
   Dimp_all((j-1)*N+1:j*N,N+1)=j;
   Difp_all((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dimp_all((j-1)*N+i,N+2)=i;
        Difp_all((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_Dimp_all.txt',Dimp_all)
dlmwrite('cfCHN_Difp_all.txt',Difp_all)


% initial trade share
for j=1:J
   Dim((j-1)*N+1:j*N,N+1)=j;
   Dif((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dim((j-1)*N+i,N+2)=i;
        Dif((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_Dim.txt',Dim)
dlmwrite('cfCHN_Dif.txt',Dif)




% Counterfactual leontief matrix

for i=1:N
    for j=1:J
        Bp_all((i-1)*J+j,N*J+1)=j;
    end
end


for i=1:N
   Bp_all((i-1)*J+1:i*J,N*J+2)=i;
end

dlmwrite('cfCHN_B_all.txt',Bp_all);

%initial leontief matrix

for i=1:N
    for j=1:J
        B_base((i-1)*J+j,N*J+1)=j;
    end
end


for i=1:N
   B_base((i-1)*J+1:i*J,N*J+2)=i;
end

dlmwrite('cfCHN_B_base.txt',B_base);




% Counterfactual price change

for j=1:J
    pfm0_all(j,N+1)=j;
    pff0_all(j,N+1)=j;
end
dlmwrite('cfCHN_pfm0_all.txt',pfm0_all);
dlmwrite('cfCHN_pff0_all.txt',pff0_all);


% Counterfactual expenditure level

for j=1:J
    PQm_all(j,N+1)=j;
    PQf_all(j,N+1)=j;
end

dlmwrite('cfCHN_PQm_all.txt',PQm_all);
dlmwrite('cfCHN_PQf_all.txt',PQf_all);


% Initial expenditure level

for j=1:J
    Xm0(j,N+1)=j;
    Xf0(j,N+1)=j;
end

dlmwrite('cfCHN_Xm0.txt',Xm0);
dlmwrite('cfCHN_Xf0.txt',Xf0);



% Counterfactual production

for j=1:J
    prod_prime(j,N+1)=j;
end
dlmwrite('cfCHN_Yprime.txt',prod_prime);



% Initial production

for j=1:J
    prod(j,N+1)=j;
end
dlmwrite('cfCHN_Y.txt',prod);

% Initial VA embodied in net inventory consumption

for j=1:J
    VAI0(j,N+1)=j;
end
dlmwrite('cfCHN_VAI0.txt',VAI0);


% counterfactual VA embodied in net inventory consumption

for j=1:J
    VAI_prime(j,N+1)=j;
end
dlmwrite('cfCHN_VAI_prime.txt',VAI_prime);



% Counterfactual wage changes
for i=1:N
    wf0_all(i,2)=i;
end
dlmwrite('cfCHN_wf0_all.txt',wf0_all)



% counterfactual tariff revenue
for i=1:N
   Rp(i,2)=i;
end
dlmwrite('cfCHN_Rprime.txt',Rp)



% initial tariff revenue
for i=1:N
   R(i,2)=i;
end
dlmwrite('cfCHN_R.txt',R)




% trade deficit
for i=1:N
   Sn(i,2)=i;
end
dlmwrite('cfCHN_S.txt',Sn)




% trade deficit + inventory
for i=1:N
   SIn(i,2)=i;
end
dlmwrite('cfCHN_SI.txt',SIn)



% initial value added
for i=1:N
   VAn(i,2)=i;
end
dlmwrite('cfCHN_VA.txt',VAn)


% inital tariffs

for j=1:J
   taum((j-1)*N+1:j*N,N+1)=j;
   tauf((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taum((j-1)*N+i,N+2)=i;
       tauf((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_taum.txt',taum)
dlmwrite('cfCHN_tauf.txt',tauf)


% counterfactual tariffs

for j=1:J
   taump((j-1)*N+1:j*N,N+1)=j;
   taufp((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taump((j-1)*N+i,N+2)=i;
       taufp((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cfCHN_taump.txt',taump)
dlmwrite('cfCHN_taufp.txt',taufp)




load(fn)


t = 2;
s = J;
a = N;


%make new directory for  every "year"

for j=1:t
    k = j-1;
    mkdir(['deco/' int2str(k)])
end


% prep matrices for decompostion
% VA COEFFICIENT
for c=1:t
    r(:,:,c) = B;  % a * s * t
end

%IO-MATRIX
pimhat=Dimp_all./Dim;
pifhat=Difp_all./Dif;

for i=1:N*J
    for j=1:N
        if isnan(pimhat(i,j))==1
            pimhat(i,j)=1;
        end
        if isnan(pifhat(i,j))==1
            pifhat(i,j)=1;
        end
    end
end

taum_hat=taump./taum ;
tauf_hat=taufp./tauf ;
 
A_prime=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            A_prime((i-1)*J+j,(n-1)*J+1:n*J)=pimhat((j-1)*N+n,i)./taum_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end

A = cat(3,A_base,A_prime);


%% TRADE FLOWS
PQm_vec   = reshape(PQm_all',1,J*N)'; 
PQf_vec   = reshape(PQf_all',1,J*N)'; 
Xm0_vec   = reshape(Xm0',1,J*N)'; 
Xf0_vec   = reshape(Xf0',1,J*N)'; 


Dimp_om = Dimp_all./taump;
Difp_om = Difp_all./taufp;
Dim_om = Dim./taum;
Dif_om = Dif./tauf;

for n = 1:1:N
    DPm(:,n)  = Dimp_om(:,n).*PQm_vec; 
    DPf(:,n)  = Difp_om(:,n).*PQf_vec; 
    D0m(:,n)  = Dim_om(:,n).*Xm0_vec; 
    D0f(:,n)  = Dif_om(:,n).*Xf0_vec;
end


% total exports by exporter 

he = eye(a); %he(11:14,11:14)=1;

for l=1:1:s
    DPm2((l-1)*a+1:l*a,:) = DPm((l-1)*a+1:l*a,:).*(1-he);
    DPf2((l-1)*a+1:l*a,:) = DPf((l-1)*a+1:l*a,:).*(1-he);
    D0m2((l-1)*a+1:l*a,:) = D0m((l-1)*a+1:l*a,:).*(1-he);
    D0f2((l-1)*a+1:l*a,:) = D0f((l-1)*a+1:l*a,:).*(1-he);
end


for l=1:1:s
    Dmp(l,:) = ones(1,a)*DPm2((l-1)*a+1:l*a,:);
    Dfp(l,:) = ones(1,a)*DPf2((l-1)*a+1:l*a,:);
    Dm(l,:) = ones(1,a)*D0m2((l-1)*a+1:l*a,:);
    Df(l,:) = ones(1,a)*D0f2((l-1)*a+1:l*a,:);
end

 %total exports by exporter and sector

Xp = Dmp+Dfp;
X0 = Dm+Df; 
 
Xp = reshape(Xp,[s*a,1]);
X0 = reshape(X0,[s*a,1]);

xx = cat(3,X0,Xp);





% final goods sales including inventory

inv = zeros(s*a,a);
for n=1:1:N
    inv((n-1)*s+1:n*s,n) = Inv(:,n);
end


%reshape final goods sales from (rows: sector importer, cols: exporter) to
% rows: exporter sector, cols importer

for n=1:1:a
        for j=1:1:s
            rDPf((n-1)*s+j,:) = DPf((j-1)*a+1:j*a,n)';
            rD0f((n-1)*s+j,:) = D0f((j-1)*a+1:j*a,n)';
            rD0f2((n-1)*s+j,:) = D0f2((j-1)*a+1:j*a,n)';
            rDPf2((n-1)*s+j,:) = DPf2((j-1)*a+1:j*a,n)';
        end
end



Cfp = rDPf + inv;
Cf = rD0f + inv;

C = cat(3,Cf,Cfp);


% final goods exports excluding intra CHN

Cc = cat(3,rD0f2,rDPf2);

%% OUTPUT
prod_prime=zeros(J,N);
prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod_prime(j,i)= PQm_all(j,:)*Dimp_om((j-1)*N+1:j*N,i)+PQf_all(j,:)*Difp_om((j-1)*N+1:j*N,i)+Inv(j,i);
            prod(j,i)= Xm0(j,:)*Dim_om((j-1)*N+1:j*N,i)+Xf0(j,:)*Dif_om((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

op = reshape(prod_prime,[s*a,1]);
o0 = reshape(prod,[s*a,1]);
o = cat(3,o0,op);


clearvars -except o C Cc A r s a t xx J N A_prime VX fn parent home


% %%%%%%%%%%%%%%%%%%%%%%%%%%             HELP MATRICES



% World Leontief scaled by va coefficient
% Leontief inverse of world input-output table for each year
B=zeros(s*a,s*a,t);

for j=1:t
  B(:,:,j) = inv(eye(a*s)-A(:,:,j));
end

vlong = reshape(r,[a*s,1,t]);

for j=1:t
    VB(:,:,j) = transpose( diag(vlong(:,:,j))*B(:,:,j) );
end

%%%%% total final goods output (exports plus domestic sales and inventory)
for j=1:t
    Y(:,:,j) = C(:,:,j)*ones(a,1);
end



% sum over importers to
% reshape final demand from
%       first dimension: sourcing country-sector
%       second dimension: demanding country
%       third dim: year

%to 
%       first dimension: sourcing country-sector
%       second dimension: year


y = zeros(a*s,1,t);

for j=1:t
    y(:,:,j) = Cc(:,:,j)*ones(a,1);
end



% matrix with total final goods export vectors on "diagonal"
for j=1:t
    for i=1:a
        ydiag((i-1)*s+1:i*s,i,j) = y((i-1)*s+1:i*s,1,j);
    end
end




%domestic leontiefs on diagonal submatrics

L = zeros(a*s,a*s,t);

for j=1:t
    for i=1:a
        L( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j )  =   inv( eye(s) - A( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j ) );
    end
end




% VB-type matrix based on domestic leontiefs only

for j=1:t
    VL(:,:,j) = transpose( diag(vlong(:,:,j))*L(:,:,j) );
end





% B-matrix without diagonals

Ih = eye(a); %Ih(11:14,11:14) = 1;

for j=1:t
    Bz(:,:,j) = ones(a*s,a*s)-kron(Ih,ones(s));
end

Bz=Bz.*B;



% B with diagonal blocks only

Bd = B-Bz;


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end



%premultiply total exports xx by domestic leontief

Lye=zeros(s*a,1,t);
for j=1:t
    Lye(:,:,j) = L(:,:,j)*xx(:,:,j);
end




% VB-type matrix based on B zero

for j=1:t
    VBz(:,:,j) = transpose( diag(vlong(:,:,j))*Bz(:,:,j) );
end


% domestic final demand (including inventory)



I = eye(a);
%I(11:14,11:14)=1;
Azc = kron(I,ones(s,1));  

cD = C.*Azc; % set-off diagonal flows to zero

yd = zeros(a*s,1,t);


for j=1:t
    yd(:,:,j) = cD(:,:,j)*ones(a,1);
end




%premultiply total domestic final good absorption by domestic leontief

Lyd=zeros(s*a,1,t);
for j=1:t
    Lyd(:,:,j) = L(:,:,j)*yd(:,:,j);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  domestic and foreign va content of total exports %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%% country-sector va content -- TRANSPOSED structure of io tab
% columns: source sectors wi countries
% rows: demanding sectors wi countries (EXPORTERS)
%--> will be transposed below

VAFE = VB.*y; %domestic and foreign value added content of final goods exports




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% domestic value added content of intermediate goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% sum of terms 2 - 9 
%%%%%%%%%%%%%%%%%%%% double-counted term 9 will be substracted below


%%%%% total final goods output (exports plus domestic sales and inventory)


% A-matrix without diagonals 

for j=1:t
    Az(:,:,j) = ones(a*s,a*s)-kron(I,ones(s));
end

Az=Az.*A;

for j=1:t
 AzBY(:,:,j) = Az(:,:,j)*B(:,:,j)*Y(:,:,j);
end


VAIE9=VL.*AzBY; % domestic value added content of intermediate goods exports including returned domestic va and - at this stage, returned and reexported  va which is substracted below



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% prep DOUBLE-COUNTED VA

%% TERMS 9 & 10: double counted domestic va



% Term 9



for j=1:t
    ABzy(:,:,j) = Az(:,:,j)*Bz(:,:,j)*ydiag(:,:,j);   
end



%set non-diagonal vectors = zero and write in column vector

ABzys = zeros(a*s,1,t);
for j=1:t
    for i=1:a
        ABzys( (i-1)*s+1:i*s,1,j) = ABzy((i-1)*s+1:i*s,i,j);
    end
end


DCDVAE9 = VL.*ABzys;   % double-counted domestic value added caused by final goods exports

VAIE=VAIE9-DCDVAE9;  %domestic va in intermediate exports net of double counting




% term 10:

for j=1:t
    Azo(:,:,j) =Az(:,:,j)*o(:,:,j);
end


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end

DCDVAE10 = (VBd-VL).*Azo;

DCDVAE=DCDVAE9+DCDVAE10;
clear DCDVAE9 DCDVAE10





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% double-counted foreign value added content of exports %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% TERMS 13 & 16: double counted foreign va


%sum over final countries
Azye=zeros(s*a,1,t);
for j=1:t
    Azye(:,1,j)=Az(:,:,j)*Lye(:,:,j);
end

DCFVAE = VBz.*Azye;  % double-counted foreign value added





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% foreign value added %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% terms 12 and 15 (structure identical to 13 & 16)

%sum over final countries
Azyd=zeros(s*a,1,t);
for j=1:t
    Azyd(:,1,j)=Az(:,:,j)*Lyd(:,:,j);
end


FVAE = VBz.*Azyd;  % double-counted foreign value added






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% transpose - source in rows, exporters in columns -> same element
% interpretation as in world input-output table


for j=1:1:t
    VAFE(:,:,j)=VAFE(:,:,j)';
    VAIE(:,:,j)=VAIE(:,:,j)';
    FVAE(:,:,j)=FVAE(:,:,j)';
    DCDVAE(:,:,j)=DCDVAE(:,:,j)';
    DCFVAE(:,:,j)=DCFVAE(:,:,j)';  
end

%total value added in exports:
TVAE = VAFE + VAIE + FVAE  + DCDVAE + DCFVAE ;



DV = VAFE + VAIE + FVAE;
DVDC = VAFE + VAIE + DCDVAE +  DCFVAE + FVAE;

%clear VAFE VAIE DCDVAE FVAE DCFVAE

Az = kron(eye(a),ones(s,s));

DV = Az.*DV; %set source! = exporter -> zero
DVDC = Az.*DVDC;

DV = sum(DV,1); % sum over source sectors
DVDC = sum(DVDC,1); % sum over source sectors

clearvars -except DV DVDC VAFE VAIE DCDVAE DCFVAE FVAE xx t s a C VB J N A_prime VX fn parent home


xx=squeeze(xx);
DV=squeeze(DV);
DVDC=squeeze(DVDC);




%%%%%%%%%%%%%%%%%%%%%%%% VAX RATIO %%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%



%load deco\DVAR


% individual export destinations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% destination-specific domestic and foreign va content %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:t %do this only for counterfactual and load baseline from previous files
    k = -1+j;
    

VAFE_bh=[]; 

 

for h = 1:a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports to x %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14

y_h = [zeros((h-1),1); 1 ; zeros((a-h),1) ];

%final goods export to destination x

    y_b(:,:) = C(:,:,j)*y_h;

%y_h = [zeros((11-1)*s,1); ones(s,1) ; zeros((a-11)*s,1) ];

VAFE_b = VB(:,:,j).*y_b; %domestic and foreign value added content of final goods exports

VAFE_b=VAFE_b';


VAFE_bh = cat(3,VAFE_bh,VAFE_b);


end


 f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');

 save(f, 'VAFE_bh', '-v7.3')

end

clear C VB y_h y_b VAFE_b



%VX = VX(:,1); %imported baseline
VX=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



for j=1:t         
    k = -1+j;
 
f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');

load(f,'VAFE_bh')

vafe = squeeze(sum(VAFE_bh,2)); %squeeze removes singleton dimension

I = eye(a);
%I(11:14,11:14)=1; %set countries fg exports to themselves =0 

he = 1-kron(I,ones(s,1));

VAX = vafe.*he*ones(a,1);

VX = [VX VAX];

end


save deco/DVAR


DV0=squeeze(DV(:,1));
VX0=squeeze(VX(:,1));


DVp=squeeze(DV(:,2));
VXp=squeeze(VX(:,2));

for i=1:N
    for j=1:J
        DV0((i-1)*J+j,2)=j;
        VX0((i-1)*J+j,2)=j;
        DVp((i-1)*J+j,2)=j;
        VXp((i-1)*J+j,2)=j;
    end
end

for i=1:N
   DV0((i-1)*J+1:i*J,3)=i;
   VX0((i-1)*J+1:i*J,3)=i;
   DVp((i-1)*J+1:i*J,3)=i;
   VXp((i-1)*J+1:i*J,3)=i;
end

dlmwrite('deco/cfCHN_DV0.txt',DV0)
dlmwrite('deco/cfCHN_VAX0.txt',VX0)

dlmwrite('deco/cfCHN_DVp.txt',DVp)
dlmwrite('deco/cfCHN_VAXp.txt',VXp)




end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% results for scenario in Table 4 row j
%%%%%%%%%%%%%%%%%%%%%%%%% 





load(fullfile(home,'OPI','WTOCHN2007OPI'));
cd(fileparts(fullfile(home,'OPI','WTOCHN2007OPI')))


A_base=load(fullfile(parent,'OPI','ioc2000.txt'));

t=1;
s=J;
a=N;


pihat=Dinp_all./Din;

for i=1:N*J
    for j=1:N
        if isnan(pihat(i,j))==1
            pihat(i,j)=1;
        end
    end
end

 
%note that Sn has to be adjusted if the inventories are present
Ip=diag(wf0_all)*VAn+(PQ_all'*(1-Fp_all)).*eye(N,N)*ones(N,1)-SIn;
I=VAn+(X0'*(1-F)).*eye(N,N)*ones(N,1)-SIn;

Rp=(PQ_all'*(1-Fp_all)).*eye(N,N)*ones(N,1);
R=(X0'*(1-F)).*eye(N,N)*ones(N,1);



%domestic production values (fob - what producers actually get)
Dinp_allf=Dinp_all./taup;
prod_prime=zeros(J,N);

for i=1:N
    for j=1:J
            prod_prime(j,i)= PQ_all(j,:)*Dinp_allf((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

Din_f=Din./tau;
prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod(j,i)= X0(j,:)*Din_f((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end


% Read out the data



% Counterfactual income
for i=1:N
    Ip(i,2)=i;
end
dlmwrite('cf_Iprime.txt',Ip)



% Initial income
for i=1:N
    I(i,2)=i;
end
dlmwrite('cf_I.txt',I)


% Counterfactual trade change
for j=1:J
    pihat((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        pihat((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cf_pihat.txt',pihat)


% Counterfactual trade share
for j=1:J
   Dinp_all((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Dinp_all((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cf_Dinp_all.txt',Dinp_all)



% initial trade share
for j=1:J
   Din((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
        Din((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cf_Din.txt',Din)





% Counterfactual price change

for j=1:J
    pf0_all(j,N+1)=j;
end
dlmwrite('cf_pf0_all.txt',pf0_all);


% Counterfactual expenditure level

for j=1:J
    PQ_all(j,N+1)=j;
end
dlmwrite('cf_PQ_all.txt',PQ_all);

% Initial expenditure level

for j=1:J
    X0(j,N+1)=j;
end
dlmwrite('cf_X0.txt',X0);



% Counterfactual production

for j=1:J
    prod_prime(j,N+1)=j;
end
dlmwrite('cf_Yprime.txt',prod_prime);



% Initial production

for j=1:J
    prod(j,N+1)=j;
end
dlmwrite('cf_Y.txt',prod);




% Counterfactual wage changes
for i=1:N
    wf0_all(i,2)=i;
end
dlmwrite('cf_wf0_all.txt',wf0_all)



% counterfactual tariff revenue
for i=1:N
   Rp(i,2)=i;
end
dlmwrite('cf_Rprime.txt',Rp)



% initial tariff revenue
for i=1:N
   R(i,2)=i;
end
dlmwrite('cf_R.txt',R)




% trade deficit
for i=1:N
   Sn(i,2)=i;
end
dlmwrite('cf_S.txt',Sn)




% trade deficit + inventory
for i=1:N
   SIn(i,2)=i;
end
dlmwrite('cf_SI.txt',SIn)



% initial value added
for i=1:N
   VAn(i,2)=i;
end
dlmwrite('cf_VA.txt',VAn)


% inital tariffs

for j=1:J
   tau((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       tau((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cf_tau.txt',tau)


% counterfactual tariffs

for j=1:J
   taup((j-1)*N+1:j*N,N+1)=j;
end

for j=1:J
    for i=1:N
       taup((j-1)*N+i,N+2)=i;
    end
end

dlmwrite('cf_taup.txt',taup)





load(fullfile(home,'OPI','WTOCHN2007OPI'))

t = 2;
s = J;
a = N;


%make new directory for  every "year"

for j=1:t
    k = j-1;
    mkdir(['deco/' int2str(k)])
end


% prep matrices for decompostion
% VA COEFFICIENT
for c=1:t
    r(:,:,c) = B;  % a * s * t
end

%IO-MATRIX
pihat=Dinp_all./Din;

for i=1:N*J
    for j=1:N
        if isnan(pihat(i,j))==1
            pihat(i,j)=1;
        end
    end
end

tau_hat=taup./tau ;
 
A_prime=zeros(N*J,N*J);
for i=1:N
    for n=1:N
        for j=1:J
            A_prime((i-1)*J+j,(n-1)*J+1:n*J)=pihat((j-1)*N+n,i)./tau_hat((j-1)*N+n,i)*A_base((i-1)*J+j,(n-1)*J+1:n*J);
        end
    end
end

A = cat(3,A_base,A_prime);


%% TRADE FLOWS
PQ_vec   = reshape(PQ_all',1,J*N)'; 
X0_vec   = reshape(X0',1,J*N)'; 


Dinp_om = Dinp_all./taup;

Din_om = Din./tau;


for n = 1:1:N
    DP(:,n)  = Dinp_om(:,n).*PQ_vec; 
    D0(:,n)  = Din_om(:,n).*X0_vec; 
end


% total exports by exporter and sector

he = eye(a); 

for l=1:1:s
    DP2((l-1)*a+1:l*a,:) = DP((l-1)*a+1:l*a,:).*(1-he);
    D02((l-1)*a+1:l*a,:) = D0((l-1)*a+1:l*a,:).*(1-he);
end


for l=1:1:s
    Dnp(l,:) = ones(1,a)*DP2((l-1)*a+1:l*a,:);
    Dn(l,:) = ones(1,a)*D02((l-1)*a+1:l*a,:);
end

 %total exports by exporter and sector

Xp = Dnp;
X0t = Dn; 
 
Xp = reshape(Xp,[s*a,1]);
X0t = reshape(X0t,[s*a,1]);

xx = cat(3,X0t,Xp);





% final goods sales including inventory

inv = zeros(s*a,a);
for n=1:1:N
    inv((n-1)*s+1:n*s,n) = Inv(:,n);
end


%note that Sn has to be adjusted if the inventories are present
Ip=diag(wf0_all)*VAn+(PQ_all'*(1-Fp_all)).*eye(N,N)*ones(N,1)-SIn;
I=VAn+(X0'*(1-F)).*eye(N,N)*ones(N,1)-SIn;


aI = alphas.*I';
aIp = alphas.*Ip';

for j=1:J
    DPf( (j-1)*a+1:j*a , :  ) = Dinp_om( (j-1)*a+1:j*a , :  ) .* aIp(j,:)';
    D0f( (j-1)*a+1:j*a , :  ) = Din_om( (j-1)*a+1:j*a , :  ) .* aI(j,:)';
end


for l=1:1:s
    DPf2((l-1)*a+1:l*a,:) = DPf((l-1)*a+1:l*a,:).*(1-he);
    D0f2((l-1)*a+1:l*a,:) = D0f((l-1)*a+1:l*a,:).*(1-he);
end


%reshape final goods sales from (rows: sector importer, cols: exporter) to
% rows: exporter sector, cols importer

for n=1:1:a
        for j=1:1:s
            rDPf((n-1)*s+j,:) = DPf((j-1)*a+1:j*a,n)';
            rD0f((n-1)*s+j,:) = D0f((j-1)*a+1:j*a,n)';
            rD0f2((n-1)*s+j,:) = D0f2((j-1)*a+1:j*a,n)';
            rDPf2((n-1)*s+j,:) = DPf2((j-1)*a+1:j*a,n)';
        end
end



Cfp = rDPf + inv;
Cf = rD0f + inv;

C = cat(3,Cf,Cfp);


% final goods exports excluding domestic sales

Cc = cat(3,rD0f2,rDPf2);

%% OUTPUT
prod_prime=zeros(J,N);
prod=zeros(J,N);
for i=1:N
    for j=1:J
            prod_prime(j,i)= PQ_all(j,:)*Dinp_om((j-1)*N+1:j*N,i)+Inv(j,i);
            prod(j,i)= X0(j,:)*Din_om((j-1)*N+1:j*N,i)+Inv(j,i);
    end
end

op = reshape(prod_prime,[s*a,1]);
o0 = reshape(prod,[s*a,1]);
o = cat(3,o0,op);


clearvars -except o C Cc A r s a t xx J N A_prime VX


% %%%%%%%%%%%%%%%%%%%%%%%%%%             HELP MATRICES



% World Leontief scaled by va coefficient
% Leontief inverse of world input-output table for each year
B=zeros(s*a,s*a,t);

for j=1:t
  B(:,:,j) = inv(eye(a*s)-A(:,:,j));
end

vlong = reshape(r,[a*s,1,t]);

for j=1:t
    VB(:,:,j) = transpose( diag(vlong(:,:,j))*B(:,:,j) );
end

%%%%% total final goods output (exports plus domestic sales and inventory)
for j=1:t
    Y(:,:,j) = C(:,:,j)*ones(a,1);
end



% sum over importers to
% reshape final demand from
%       first dimension: sourcing country-sector
%       second dimension: demanding country
%       third dim: year

%to 
%       first dimension: sourcing country-sector
%       second dimension: year


y = zeros(a*s,1,t);

for j=1:t
    y(:,:,j) = Cc(:,:,j)*ones(a,1);
end



% matrix with total final goods export vectors on "diagonal"
for j=1:t
    for i=1:a
        ydiag((i-1)*s+1:i*s,i,j) = y((i-1)*s+1:i*s,1,j);
    end
end




%domestic leontiefs on diagonal submatrics

L = zeros(a*s,a*s,t);

for j=1:t
    for i=1:a
        L( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j )  =   inv( eye(s) - A( (i-1)*s+1:i*s,(i-1)*s+1:i*s,j ) );
    end
end


%% !!!! replace intra-CHN Leontief
%for j=1:t
 %   L( 10*s+1:14*s,10*s+1:14*s,j) = inv(eye(4*s)-A(10*s+1:14*s,10*s+1:14*s,j));
%end


% VB-type matrix based on domestic leontiefs only

for j=1:t
    VL(:,:,j) = transpose( diag(vlong(:,:,j))*L(:,:,j) );
end





% B-matrix without diagonals and without intra-China

Ih = eye(a); %Ih(11:14,11:14) = 1;

for j=1:t
    Bz(:,:,j) = ones(a*s,a*s)-kron(Ih,ones(s));
end

Bz=Bz.*B;



% B with diagonal blocks only

Bd = B-Bz;


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end



%premultiply total exports xx by domestic leontief

Lye=zeros(s*a,1,t);
for j=1:t
    Lye(:,:,j) = L(:,:,j)*xx(:,:,j);
end




% VB-type matrix based on B zero

for j=1:t
    VBz(:,:,j) = transpose( diag(vlong(:,:,j))*Bz(:,:,j) );
end


% domestic final demand (including inventory)



I = eye(a);
%I(11:14,11:14)=1;
Azc = kron(I,ones(s,1));  

cD = C.*Azc; % set-off diagonal and non-intra-CHN flows to zero

yd = zeros(a*s,1,t);


for j=1:t
    yd(:,:,j) = cD(:,:,j)*ones(a,1);
end




%premultiply total domestic final good absorption by domestic leontief

Lyd=zeros(s*a,1,t);
for j=1:t
    Lyd(:,:,j) = L(:,:,j)*yd(:,:,j);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  domestic and foreign va content of total exports %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%% country-sector va content -- TRANSPOSED structure of io tab
% columns: source sectors wi countries
% rows: demanding sectors wi countries (EXPORTERS)
%--> will be transposed below

VAFE = VB.*y; %domestic and foreign value added content of final goods exports




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% domestic value added content of intermediate goods exports %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%% sum of terms 2 - 9 
%%%%%%%%%%%%%%%%%%%% double-counted term 9 will be substracted below


%%%%% total final goods output (exports plus domestic sales and inventory)


% A-matrix without diagonals 

for j=1:t
    Az(:,:,j) = ones(a*s,a*s)-kron(I,ones(s));
end

Az=Az.*A;

for j=1:t
 AzBY(:,:,j) = Az(:,:,j)*B(:,:,j)*Y(:,:,j);
end


VAIE9=VL.*AzBY; % domestic value added content of intermediate goods exports including returned domestic va and - at this stage, returned and reexported  va which is substracted below



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% prep DOUBLE-COUNTED VA

%% TERMS 9 & 10: double counted domestic va



% Term 9



for j=1:t
    ABzy(:,:,j) = Az(:,:,j)*Bz(:,:,j)*ydiag(:,:,j);   
end



%set non-diagonal vectors = zero and write in column vector

ABzys = zeros(a*s,1,t);
for j=1:t
    for i=1:a
        ABzys( (i-1)*s+1:i*s,1,j) = ABzy((i-1)*s+1:i*s,i,j);
    end
end


DCDVAE9 = VL.*ABzys;   % double-counted domestic value added caused by final goods exports

VAIE=VAIE9-DCDVAE9;  %domestic va in intermediate exports net of double counting




% term 10:

for j=1:t
    Azo(:,:,j) =Az(:,:,j)*o(:,:,j);
end


% VB-type matrix based on B diag only

for j=1:t
    VBd(:,:,j) = transpose( diag(vlong(:,:,j))*Bd(:,:,j) );
end

DCDVAE10 = (VBd-VL).*Azo;

DCDVAE=DCDVAE9+DCDVAE10;
clear DCDVAE9 DCDVAE10





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% double-counted foreign value added content of exports %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% TERMS 13 & 16: double counted foreign va


%sum over final countries
Azye=zeros(s*a,1,t);
for j=1:t
    Azye(:,1,j)=Az(:,:,j)*Lye(:,:,j);
end

DCFVAE = VBz.*Azye;  % double-counted foreign value added





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% foreign value added %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% terms 12 and 15 (structure identical to 13 & 16)

%sum over final countries
Azyd=zeros(s*a,1,t);
for j=1:t
    Azyd(:,1,j)=Az(:,:,j)*Lyd(:,:,j);
end


FVAE = VBz.*Azyd;  % double-counted foreign value added






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% transpose - source in rows, exporters in columns -> same element
% interpretation as in world input-output table


for j=1:1:t
    VAFE(:,:,j)=VAFE(:,:,j)';
    VAIE(:,:,j)=VAIE(:,:,j)';
    FVAE(:,:,j)=FVAE(:,:,j)';
    DCDVAE(:,:,j)=DCDVAE(:,:,j)';
    DCFVAE(:,:,j)=DCFVAE(:,:,j)';  
end

%total value added in exports:
TVAE = VAFE + VAIE + FVAE  + DCDVAE + DCFVAE ;




DV = VAFE + VAIE + FVAE;
DVDC = VAFE + VAIE + DCDVAE +  DCFVAE + FVAE;

%clear VAFE VAIE DCDVAE FVAE DCFVAE

Az = kron(eye(a),ones(s,s));
%Az(10*s+1:14*s,10*s+1:14*s)=1;  % the within China connections

DV = Az.*DV; %set source! = exporter -> zero
DVDC = Az.*DVDC;

DV = sum(DV,1); % sum over source sectors
DVDC = sum(DVDC,1); % sum over source sectors

clearvars -except DV DVDC VAFE VAIE DCDVAE DCFVAE FVAE xx t s a C VB J N A_prime VX


xx=squeeze(xx);
DV=squeeze(DV);
DVDC=squeeze(DVDC);




%%%%%%%%%%%%%%%%%%%%%%%% VAX RATIO %%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%



%load deco\DVAR


% individual export destinations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% destination-specific domestic and foreign va content %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j=1:t %do this only for counterfactual and load baseline from previous files
    k = -1+j;
    

VAFE_bh=[]; 

 

for h = 1:a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% value added content of final goods exports to x %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% terms 1, 11, 14

y_h = [zeros((h-1),1); 1 ; zeros((a-h),1) ];

%final goods export to destination x

    y_b(:,:) = C(:,:,j)*y_h;

%y_h = [zeros((11-1)*s,1); ones(s,1) ; zeros((a-11)*s,1) ];

VAFE_b = VB(:,:,j).*y_b; %domestic and foreign value added content of final goods exports

VAFE_b=VAFE_b';


VAFE_bh = cat(3,VAFE_bh,VAFE_b);


end


 f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');

 save(f, 'VAFE_bh', '-v7.3')

end

clear C VB y_h y_b VAFE_b


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% change
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% this when
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% computing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% new or
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% different
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% baseline
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% for OOC
%VX = VX(:,1); %imported baseline
VX=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



for j=1:t          % change this when adjusting baseline!
    k = -1+j;
 
f = fullfile(['deco/' int2str(k)],'VAFE_bh.mat');

load(f,'VAFE_bh')

vafe = squeeze(sum(VAFE_bh,2)); %squeeze removes singleton dimension

I = eye(a); %I(11:14,11:14)=1; %set countries fg exports to themselves =0 and set all Chinas' fg exports to the other Chinas = 0

he = 1-kron(I,ones(s,1));

VAX = vafe.*he*ones(a,1);

VX = [VX VAX];

end

save deco/DVAR


DV0=squeeze(DV(:,1));
VX0=squeeze(VX(:,1));


DVp=squeeze(DV(:,2));
VXp=squeeze(VX(:,2));

for i=1:N
    for j=1:J
        DV0((i-1)*J+j,2)=j;
        VX0((i-1)*J+j,2)=j;
        DVp((i-1)*J+j,2)=j;
        VXp((i-1)*J+j,2)=j;
    end
end

for i=1:N
   DV0((i-1)*J+1:i*J,3)=i;
   VX0((i-1)*J+1:i*J,3)=i;
   DVp((i-1)*J+1:i*J,3)=i;
   VXp((i-1)*J+1:i*J,3)=i;
end

dlmwrite('deco/cfCHN_DV0.txt',DV0)
dlmwrite('deco/cfCHN_VAX0.txt',VX0)

dlmwrite('deco/cfCHN_DVp.txt',DVp)
dlmwrite('deco/cfCHN_VAXp.txt',VXp)

