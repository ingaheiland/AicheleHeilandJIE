% This function calculates de Omega matrix in Caliendo - Parro (2009)
% Inputs are A = alphas, B = bethas, G = I-O matrix, Dinp = trade shares,
% tarifap = tarifs, Fp = trade weighted tariffs

function [PQm PQf] = expenditure_MF(alphas,B,G,Dimp,Difp,taump,taufp,Fmp,Ffp,VAn,wf0,SIn,VP,J,N) %note that originally there was ***Sn*** in this place

% [J N] = size(A);
IAm  = zeros(J*N,J*N);  
IAf  = zeros(J*N,J*N);
I_Fm = 1 - Fmp;
I_Ff = 1 - Ffp;
for n = 1:1:N
    IAm(1 + (n-1)*J : n*J, 1 + (n-1)*J : n*J) = kron(alphas(:,n),I_Fm(:,n)');
    IAf(1 + (n-1)*J : n*J, 1 + (n-1)*J : n*J) = kron(alphas(:,n),I_Ff(:,n)');
end


Pimt = Dimp./(taump);
Pift = Difp./(taufp);
Bt  = 1-B;
BPm  = zeros(size(Pimt));
BPf  = zeros(size(Pift));

for j = 1:1:J
    BPm(1 + (j-1)*N:j*N, :) = kron(ones(N,1),Bt(j,:)).*Pimt(1 + (j-1)*N:j*N, :);
    BPf(1 + (j-1)*N:j*N, :) = kron(ones(N,1),Bt(j,:)).*Pift(1 + (j-1)*N:j*N, :);
end

NBPm = zeros(size(BPm'));
NBPf = zeros(size(BPf'));

for j = 1:1:N
    for n = 1:1:N
        NBPm(j , 1 + (n-1)*J : n*J) = BPm([n:N:J*N], j);
        NBPf(j , 1 + (n-1)*J : n*J) = BPf([n:N:J*N], j);
    end
end

NNBPm = kron(NBPm,ones(J,1));
NNBPf = kron(NBPf,ones(J,1));

GG   = kron(ones(1,N),G);
GPm = GG.*NNBPm;
GPf = GG.*NNBPf;

HF = [GPm GPf; IAm IAf];

OM = eye(J*N*2,J*N*2) - HF; 
Vb =    alphas.*kron(ones(J,1),(wf0.*VAn)');
Vb = reshape(Vb,J*N,1);
Bb =  -alphas.*((SIn)*ones(1,J))'; %note that originally there was ***Sn*** in this place
Bb = reshape(Bb,J*N,1);
V = reshape(VP,J*N,1);
Bb = Bb+Vb;
Bb = [V; Bb]; % add zeros LHS for interm. goods expenditure

PQ_vec = (OM^-1)*(Bb);  % sorted Xji as [X11 X21 X31 X12 X22 X32]
%DD2 = (OM^-1)*Bb;
%PQ =  DD1; % + DD2;
PQm = reshape(PQ_vec(1:N*J),J,N);
PQf = reshape(PQ_vec(N*J+1:2*N*J),J,N);
